import { i as __toESM } from "./_runtime.mjs";
import { t as cn } from "./_ssr/utils-_83nvF2z.mjs";
import { E as require_jsx_runtime, T as require_react, d as DialogClose, f as DialogContent$1, h as DialogTitle$1, m as DialogPortal, p as DialogOverlay, u as Dialog$1 } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./_ssr/button-c9IIymTs.mjs";
import { n as useSettings, t as initSettingsDom } from "./_ssr/settings-CfMxctWi.mjs";
import { i as useProgress } from "./_ssr/progress-DkeQVu5t.mjs";
import { n as KATAKANA, t as HIRAGANA } from "./_ssr/kana-CV-aAiLY.mjs";
import { n as KANJI_N5, t as KANJI_N4 } from "./_ssr/kanji-n4-Bq9tkueZ.mjs";
import { t as LESSONS } from "./_ssr/lessons-C7yMsqVQ.mjs";
import { b as useRouter, d as useRouterState, m as Outlet, v as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { D as BookText, O as BookOpen, T as ChartColumn, _ as Headphones, a as Star, c as RotateCcw, d as Map$1, g as House, h as Languages, k as BookMarked, l as PenTool, m as Layers, o as Settings, p as Library, r as Type, s as Search, t as X, u as Menu, v as GraduationCap, x as CircleHelp } from "./_libs/lucide-react.mjs";
import { t as Input } from "./_ssr/input-D2VeMEL1.mjs";
import { n as GRAMMAR_N5, t as GRAMMAR_N4 } from "./_ssr/grammar-n4-Dv0a1spF.mjs";
import { r as normalizeRomaji } from "./_ssr/romaji-DAIxYx-y.mjs";
import { n as searchLocal } from "./_ssr/local-CAR8tw6H.mjs";
import { n as builtinDictionary } from "./_ssr/catalog-Dl3G3Fgy.mjs";
import { t as Toaster } from "./_libs/sonner.mjs";
import { t as Provider } from "./_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-CHxEqIiA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog$1;
function SheetContent({ className, children, side = "left", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed z-50 bg-surface text-fg shadow-[var(--shadow-soft)]", side === "left" && "inset-y-0 left-0 h-full w-[min(20rem,88vw)] border-r border-border", side === "right" && "inset-y-0 right-0 h-full w-[min(20rem,88vw)] border-l border-border", side === "bottom" && "inset-x-0 bottom-0 max-h-[85vh] rounded-t-xl border-t border-border", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute right-3 top-3 rounded-sm p-1 text-muted hover:bg-bg-elevated",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Đóng"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("p-5 pb-2", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-base font-semibold", className),
		...props
	});
}
function TooltipProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration: 250,
		children
	});
}
var NAV = [
	{
		to: "/",
		label: "Trang chủ",
		icon: House,
		group: "Chính"
	},
	{
		to: "/path",
		label: "Lộ trình",
		icon: Map$1,
		group: "Chính"
	},
	{
		to: "/alphabet",
		label: "Bảng chữ cái",
		icon: Languages,
		group: "Chữ"
	},
	{
		to: "/hiragana",
		label: "Hiragana",
		icon: Type,
		group: "Chữ"
	},
	{
		to: "/katakana",
		label: "Katakana",
		icon: Type,
		group: "Chữ"
	},
	{
		to: "/romaji",
		label: "Romaji",
		icon: PenTool,
		group: "Chữ"
	},
	{
		to: "/kanji",
		label: "Kanji",
		icon: Library,
		group: "Kiến thức"
	},
	{
		to: "/vocabulary",
		label: "Từ vựng",
		icon: BookOpen,
		group: "Kiến thức"
	},
	{
		to: "/grammar",
		label: "Ngữ pháp",
		icon: GraduationCap,
		group: "Kiến thức"
	},
	{
		to: "/dictionary",
		label: "Từ điển",
		icon: BookMarked,
		group: "Kiến thức"
	},
	{
		to: "/flashcards",
		label: "Flashcard",
		icon: Layers,
		group: "Luyện"
	},
	{
		to: "/listen",
		label: "Luyện nghe",
		icon: Headphones,
		group: "Luyện"
	},
	{
		to: "/read",
		label: "Luyện đọc",
		icon: BookText,
		group: "Luyện"
	},
	{
		to: "/quiz",
		label: "Quiz",
		icon: CircleHelp,
		group: "Luyện"
	},
	{
		to: "/review",
		label: "Ôn tập",
		icon: RotateCcw,
		group: "Luyện"
	},
	{
		to: "/stats",
		label: "Thống kê",
		icon: ChartColumn,
		group: "Tôi"
	},
	{
		to: "/favorites",
		label: "Yêu thích",
		icon: Star,
		group: "Tôi"
	},
	{
		to: "/my-words",
		label: "Từ của tôi",
		icon: BookMarked,
		group: "Tôi"
	},
	{
		to: "/settings",
		label: "Cài đặt",
		icon: Settings,
		group: "Tôi"
	}
];
var MOBILE_TAB = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/path",
		label: "Lộ trình",
		icon: Map$1
	},
	{
		to: "/dictionary",
		label: "Từ điển",
		icon: Search
	},
	{
		to: "/review",
		label: "Ôn",
		icon: RotateCcw
	},
	{
		to: "/settings",
		label: "Thêm",
		icon: Settings
	}
];
var Dialog = Dialog$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/40 data-[state=open]:animate-in" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed left-1/2 top-1/2 z-50 w-[min(560px,calc(100vw-1.5rem))] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-surface p-5 text-fg shadow-[var(--shadow-soft)]", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute right-3 top-3 rounded-sm p-1 text-muted hover:bg-bg-elevated",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Đóng"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-3 space-y-1", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-lg font-semibold", className),
		...props
	});
}
function SearchDialog({ open, onOpenChange }) {
	const [q, setQ] = (0, import_react.useState)("");
	const router = useRouter();
	const dict = (0, import_react.useMemo)(() => builtinDictionary(), []);
	const results = (0, import_react.useMemo)(() => {
		const query = q.trim();
		if (query.length < 1) return [];
		const nq = normalizeRomaji(query);
		const out = [];
		for (const k of [...HIRAGANA, ...KATAKANA]) if (k.char === query || k.romaji === nq || k.romaji.startsWith(nq) || k.id.includes(query)) out.push({
			type: k.kind === "hiragana" ? "Hiragana" : "Katakana",
			title: k.char,
			sub: k.romaji,
			to: `/${k.kind}/${k.id}`
		});
		for (const kj of [...KANJI_N5, ...KANJI_N4]) if (kj.character === query || kj.meaning_vi.includes(query) || kj.onyomi.some((x) => x.includes(query)) || kj.kunyomi.some((x) => x.includes(query))) out.push({
			type: "Kanji",
			title: kj.character,
			sub: kj.meaning_vi,
			to: `/kanji/${kj.id}`
		});
		for (const g of [...GRAMMAR_N5, ...GRAMMAR_N4]) if (g.name.includes(query) || g.structure.includes(query) || g.meaning_vi.includes(query)) out.push({
			type: "Ngữ pháp",
			title: g.name,
			sub: g.meaning_vi,
			to: `/grammar/${g.id}`
		});
		for (const l of LESSONS) if (l.title.toLowerCase().includes(query.toLowerCase()) || l.summary.includes(query)) out.push({
			type: "Bài học",
			title: l.title,
			sub: l.summary,
			to: `/path/${l.id}`
		});
		for (const d of searchLocal(dict, {
			q: query,
			limit: 8
		})) out.push({
			type: "Từ điển",
			title: d.kanji,
			sub: `${d.kana} · ${d.meanings[0]}`,
			to: `/dictionary/${d.id}`
		});
		return out.slice(0, 20);
	}, [dict, q]);
	(0, import_react.useEffect)(() => {
		if (!open) setQ("");
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "p-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
					className: "sr-only",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Tìm kiếm" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						autoFocus: true,
						placeholder: "Kanji, kana, romaji, tiếng Việt...",
						value: q,
						onChange: (e) => setQ(e.target.value),
						"aria-label": "Tìm kiếm toàn cục"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "max-h-80 overflow-y-auto pb-3",
					children: [q && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-4 py-6 text-center text-sm text-muted",
						children: "Không tìm thấy."
					}) : null, results.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-bg-elevated",
						onClick: () => {
							onOpenChange(false);
							router.history.push(r.to);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-20 shrink-0 text-[11px] uppercase tracking-wide text-subtle",
								children: r.type
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-jp text-base",
								children: r.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm text-muted",
								children: r.sub
							})
						]
					}) }, `${r.to}-${i}`))]
				})
			]
		})
	});
}
function NavLinks({ onNavigate }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const groups = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const item of NAV) {
			const list = map.get(item.group) ?? [];
			list.push(item);
			map.set(item.group, list);
		}
		return [...map.entries()];
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex flex-col gap-5",
		"aria-label": "Điều hướng chính",
		children: groups.map(([group, items]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 px-3 text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
			children: group
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-0.5",
			children: items.map((item) => {
				const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					onClick: onNavigate,
					className: cn("flex h-10 items-center gap-2.5 rounded-[10px] px-3 text-sm transition-colors", active ? "bg-primary text-primary-fg" : "text-muted hover:bg-bg-elevated hover:text-fg"),
					"aria-current": active ? "page" : void 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), item.label]
				}) }, item.to);
			})
		})] }, group))
	});
}
function AppShell({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [search, setSearch] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const load = useProgress((s) => s.load);
	const applyDom = useSettings((s) => s.applyDom);
	const theme = useSettings((s) => s.theme);
	(0, import_react.useEffect)(() => {
		initSettingsDom();
		applyDom();
		load();
	}, [applyDom, load]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				setSearch(true);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-60 overflow-y-auto border-r border-border bg-bg-elevated/80 px-3 py-5 backdrop-blur-sm lg:flex lg:flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "mb-4 flex items-center gap-2.5 px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-9 items-center justify-center rounded-[10px] bg-primary font-display text-lg text-primary-fg",
							children: "明"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-semibold leading-tight",
							children: "Akari"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[11px] text-muted",
							children: "Học tiếng Nhật"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSearch(true),
						className: "mb-5 flex h-10 w-full items-center gap-2 rounded-[10px] border border-border bg-surface px-3 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-left",
								children: "Tìm kiếm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
								className: "rounded border border-border px-1.5 text-[10px]",
								children: "⌘K"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex h-14 items-center gap-2 border-b border-border bg-bg/90 px-3 backdrop-blur-sm lg:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Mở menu",
						onClick: () => setOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-8 items-center justify-center rounded-md bg-primary font-display text-primary-fg",
							children: "明"
						}), "Akari"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						className: "ml-auto",
						"aria-label": "Tìm kiếm",
						onClick: () => setSearch(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					side: "left",
					className: "overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Akari" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-2 pb-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, { onNavigate: () => setOpen(false) })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "px-4 pb-24 pt-6 lg:ml-60 lg:px-10 lg:pb-12 lg:pt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "akari-rise mx-auto w-full max-w-5xl",
					children
				}, pathname)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-border bg-surface/95 px-1 py-1 backdrop-blur-sm lg:hidden",
				style: { paddingBottom: "max(0.35rem, env(safe-area-inset-bottom))" },
				"aria-label": "Thanh điều hướng",
				children: MOBILE_TAB.map((item) => {
					const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-md text-[10px]", active ? "text-primary" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
					}, item.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchDialog, {
				open: search,
				onOpenChange: setSearch
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: theme === "dark" ? "dark" : theme === "light" ? "light" : "system",
				position: "bottom-center"
			})
		]
	}) });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
//#endregion
export { SplitComponent as component };
