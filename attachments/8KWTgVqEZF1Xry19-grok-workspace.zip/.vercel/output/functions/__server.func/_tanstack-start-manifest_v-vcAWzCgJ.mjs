//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-vcAWzCgJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_app"],
		preloads: [
			"/assets/index-BauKMfOp.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/link-CrEUzEa7.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/useMatch-BufLmTQx.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BauKMfOp.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/alphabet",
			"/_app/dictionary",
			"/_app/favorites",
			"/_app/flashcards",
			"/_app/grammar",
			"/_app/hiragana",
			"/_app/kanji",
			"/_app/katakana",
			"/_app/listen",
			"/_app/my-words",
			"/_app/path",
			"/_app/quiz",
			"/_app/read",
			"/_app/review",
			"/_app/romaji",
			"/_app/settings",
			"/_app/stats",
			"/_app/vocabulary",
			"/_app/",
			"/_app/tools/import-dictionary"
		],
		preloads: [
			"/assets/_app-BgdOS_j1.js",
			"/assets/rotate-ccw-DnvoLsxd.js",
			"/assets/search-C_8uKWXI.js",
			"/assets/star--BzVmcXG.js",
			"/assets/dist-BCrBlB2I.js",
			"/assets/utils-HeNywQfW.js",
			"/assets/dist-CvPqkO_I.js",
			"/assets/button-Db8GKxHX.js",
			"/assets/dist-DGj9NHzd.js",
			"/assets/dist-Db3VC6Mf.js",
			"/assets/settings-CTw1N7pk.js",
			"/assets/progress-DA6VYWvo.js",
			"/assets/input-BTeZBggf.js",
			"/assets/kana-D361Ufq3.js",
			"/assets/kanji-n4-BR6Zy5sq.js",
			"/assets/grammar-n4-C1t2ZdUa.js",
			"/assets/lessons-DI9rGF4p.js",
			"/assets/romaji-CarofOpx.js",
			"/assets/local-D7XekTFa.js",
			"/assets/catalog-D2Er2wfh.js"
		]
	},
	"/_app/alphabet": {
		filePath: "/workspace/src/routes/_app/alphabet.tsx",
		children: void 0,
		preloads: [
			"/assets/alphabet-DIrqkxYJ.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/dictionary": {
		filePath: "/workspace/src/routes/_app/dictionary.tsx",
		children: ["/_app/dictionary/$id"],
		preloads: [
			"/assets/dictionary-D3lElqk0.js",
			"/assets/storage-EWPF7Nhu.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/badge-DIosm_Zk.js",
			"/assets/empty-state-Dx8pTd_O.js"
		]
	},
	"/_app/favorites": {
		filePath: "/workspace/src/routes/_app/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-DZuyJWOY.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/empty-state-Dx8pTd_O.js",
			"/assets/dynamic-link-BvqXgpRu.js"
		]
	},
	"/_app/flashcards": {
		filePath: "/workspace/src/routes/_app/flashcards.tsx",
		children: void 0,
		preloads: [
			"/assets/flashcards-CO1NgynA.js",
			"/assets/vocabulary-n4-Bg4WER5b.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/flashcard-deck-a_QTb91F.js"
		]
	},
	"/_app/grammar": {
		filePath: "/workspace/src/routes/_app/grammar.tsx",
		children: ["/_app/grammar/$id"],
		preloads: [
			"/assets/grammar-FmDoQV8K.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/badge-DIosm_Zk.js"
		]
	},
	"/_app/hiragana": {
		filePath: "/workspace/src/routes/_app/hiragana.tsx",
		children: ["/_app/hiragana/$id"],
		preloads: [
			"/assets/hiragana-o9K2K6lx.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/kana-chart-tZHkrdPD.js"
		]
	},
	"/_app/kanji": {
		filePath: "/workspace/src/routes/_app/kanji.tsx",
		children: ["/_app/kanji/$id"],
		preloads: [
			"/assets/kanji-BC882Vkg.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/badge-DIosm_Zk.js"
		]
	},
	"/_app/katakana": {
		filePath: "/workspace/src/routes/_app/katakana.tsx",
		children: ["/_app/katakana/$id"],
		preloads: [
			"/assets/katakana-BCj5h60l.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/kana-chart-tZHkrdPD.js"
		]
	},
	"/_app/listen": {
		filePath: "/workspace/src/routes/_app/listen.tsx",
		children: void 0,
		preloads: [
			"/assets/listen-CxSTDMju.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/storage-EWPF7Nhu.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/my-words": {
		filePath: "/workspace/src/routes/_app/my-words.tsx",
		children: void 0,
		preloads: [
			"/assets/my-words-gsfcG0Bp.js",
			"/assets/storage-EWPF7Nhu.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js",
			"/assets/empty-state-Dx8pTd_O.js",
			"/assets/dynamic-link-BvqXgpRu.js",
			"/assets/label-Oxgyceks.js",
			"/assets/import-qCC1Sebk.js"
		]
	},
	"/_app/path": {
		filePath: "/workspace/src/routes/_app/path.tsx",
		children: ["/_app/path/$id"],
		preloads: [
			"/assets/path-CLIMoxXG.js",
			"/assets/check-_bxJ4H_J.js",
			"/assets/switch-Clt18UVw.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/label-Oxgyceks.js"
		]
	},
	"/_app/quiz": {
		filePath: "/workspace/src/routes/_app/quiz.tsx",
		children: void 0,
		preloads: [
			"/assets/quiz-ZNZWLqhf.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/storage-EWPF7Nhu.js",
			"/assets/vocabulary-n4-Bg4WER5b.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/read": {
		filePath: "/workspace/src/routes/_app/read.tsx",
		children: void 0,
		preloads: [
			"/assets/read-QxTSWmnZ.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/review": {
		filePath: "/workspace/src/routes/_app/review.tsx",
		children: void 0,
		preloads: [
			"/assets/review-COOpZKjj.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/empty-state-Dx8pTd_O.js",
			"/assets/flashcard-deck-a_QTb91F.js"
		]
	},
	"/_app/romaji": {
		filePath: "/workspace/src/routes/_app/romaji.tsx",
		children: void 0,
		preloads: [
			"/assets/romaji-CbmUMCIv.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/settings": {
		filePath: "/workspace/src/routes/_app/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-C1y5jnL1.js",
			"/assets/switch-Clt18UVw.js",
			"/assets/storage-EWPF7Nhu.js",
			"/assets/vocabulary-n4-Bg4WER5b.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js",
			"/assets/label-Oxgyceks.js"
		]
	},
	"/_app/stats": {
		filePath: "/workspace/src/routes/_app/stats.tsx",
		children: void 0,
		preloads: [
			"/assets/stats-B25Wqadr.js",
			"/assets/vocabulary-n4-Bg4WER5b.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js",
			"/assets/progress-MA3ayDgF.js"
		]
	},
	"/_app/vocabulary": {
		filePath: "/workspace/src/routes/_app/vocabulary.tsx",
		children: ["/_app/vocabulary/$id"],
		preloads: [
			"/assets/vocabulary-BQI2-ANo.js",
			"/assets/vocabulary-n4-Bg4WER5b.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/badge-DIosm_Zk.js"
		]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-COx_lZqA.js",
			"/assets/vocabulary-n4-Bg4WER5b.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js",
			"/assets/progress-MA3ayDgF.js"
		]
	},
	"/_app/dictionary/$id": {
		filePath: "/workspace/src/routes/_app/dictionary.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/dictionary._id-pGQ5SQoY.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/grammar/$id": {
		filePath: "/workspace/src/routes/_app/grammar.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/grammar._id-B1JH5qnb.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/hiragana/$id": {
		filePath: "/workspace/src/routes/_app/hiragana.$id.tsx",
		children: void 0,
		preloads: ["/assets/hiragana._id-DWk6UCBZ.js", "/assets/study-kana-B7pIL0Es.js"]
	},
	"/_app/kanji/$id": {
		filePath: "/workspace/src/routes/_app/kanji.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/kanji._id-vk9gtw_O.js",
			"/assets/write-canvas-Bj8HNAd9.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/card-EZXbjYYu.js"
		]
	},
	"/_app/katakana/$id": {
		filePath: "/workspace/src/routes/_app/katakana.$id.tsx",
		children: void 0,
		preloads: ["/assets/katakana._id-n1qdCzuG.js", "/assets/study-kana-B7pIL0Es.js"]
	},
	"/_app/path/$id": {
		filePath: "/workspace/src/routes/_app/path.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/path._id-5U-57tNt.js",
			"/assets/card-EZXbjYYu.js",
			"/assets/badge-DIosm_Zk.js"
		]
	},
	"/_app/tools/import-dictionary": {
		filePath: "/workspace/src/routes/_app/tools.import-dictionary.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.import-dictionary-CbRT4yL8.js",
			"/assets/storage-EWPF7Nhu.js",
			"/assets/page-header-tS0jKY2-.js",
			"/assets/card-EZXbjYYu.js",
			"/assets/badge-DIosm_Zk.js",
			"/assets/import-qCC1Sebk.js"
		]
	},
	"/_app/vocabulary/$id": {
		filePath: "/workspace/src/routes/_app/vocabulary.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vocabulary._id-DMztHRoV.js",
			"/assets/speak-button-CDvjgZ73.js",
			"/assets/storage-EWPF7Nhu.js",
			"/assets/card-EZXbjYYu.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
