import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-c9IIymTs.mjs";
import { n as useSettings } from "./settings-CfMxctWi.mjs";
import { i as useProgress } from "./progress-DkeQVu5t.mjs";
import { n as KANJI_N5, t as KANJI_N4 } from "./kanji-n4-Bq9tkueZ.mjs";
import { n as CardContent, t as Card } from "./card-7M-NYlJ1.mjs";
import { v as Link, z as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$4 } from "./router-YoCxU7dM.mjs";
import { t as Badge } from "./badge-COPtWlVw.mjs";
import { t as SpeakButton } from "./speak-button-DDCQe5zF.mjs";
import { t as WriteCanvas } from "./write-canvas-0QC5jDc4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kanji._id-CLpWTEe_.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { id } = Route$4.useParams();
	const k = [...KANJI_N5, ...KANJI_N4].find((x) => x.id === id);
	if (!k) throw notFound();
	const remember = useProgress((s) => s.remember);
	const forgot = useProgress((s) => s.forgot);
	const showRomaji = useSettings((s) => s.showRomaji);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex flex-col items-center py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: k.level }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-kana mt-3 text-[8rem] leading-none",
						children: k.character
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg",
						children: k.meaning_vi
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeakButton, {
						className: "mt-4",
						text: k.character
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm text-muted",
					children: "Onyomi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-jp text-xl",
					children: k.onyomi.join(" · ")
				})] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm text-muted",
					children: "Kunyomi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-jp text-xl",
					children: k.kunyomi.filter(Boolean).join(" · ") || "—"
				})] }) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm text-muted",
				children: "Từ ví dụ"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: k.examples.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dictionary",
						search: { q: ex.word },
						className: "font-jp text-lg hover:underline",
						children: ex.word
					}),
					showRomaji ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-sm text-accent",
						children: ex.romaji
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-sm text-muted",
						children: ex.meaning_vi
					})
				] }, ex.word))
			})] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-2 text-sm text-muted",
				children: [k.stroke_count, " nét"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WriteCanvas, {
				character: k.character,
				strokeCount: k.stroke_count
			})] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => void forgot(k.id, "kanji"),
					children: "Cần ôn"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "success",
					onClick: () => void remember(k.id, "kanji"),
					children: "Đã nhớ"
				})]
			})
		]
	});
}
//#endregion
export { Page as component };
