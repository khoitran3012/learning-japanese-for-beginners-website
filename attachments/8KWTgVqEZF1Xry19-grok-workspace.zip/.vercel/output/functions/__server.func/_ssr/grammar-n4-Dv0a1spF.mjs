//#region node_modules/.nitro/vite/services/ssr/assets/grammar-n4-Dv0a1spF.js
function g$1(n, name, structure, meaning_vi, usage, examples, mistakes, notes, related) {
	return {
		id: `g-n5-${String(n).padStart(2, "0")}`,
		name,
		structure,
		meaning_vi,
		usage,
		level: "N5",
		examples,
		mistakes,
		notes,
		related
	};
}
var GRAMMAR_N5 = [
	g$1(1, "です", "Danh từ / tính từ + です", "Là / thì (thể lịch sự, khẳng định ở hiện tại)", "です đứng cuối câu để nói một cách lịch sự rằng A là B. Không chia theo ngôi. Phủ định là ではありません / じゃありません. Nghi vấn thêm か.", [
		{
			jp: "私は学生です。",
			kana: "わたしはがくせいです。",
			romaji: "Watashi wa gakusei desu.",
			vi: "Tôi là học sinh."
		},
		{
			jp: "今日は晴れです。",
			kana: "きょうははれです。",
			romaji: "Kyou wa hare desu.",
			vi: "Hôm nay trời nắng."
		},
		{
			jp: "あれは駅ですか。",
			kana: "あれはえきですか。",
			romaji: "Are wa eki desu ka.",
			vi: "Kia có phải nhà ga không?"
		}
	], ["Không nói 私は学生だです。 Chỉ dùng だ hoặc です, không chồng hai cái.", "Phủ định không phải ですせん mà là ではありません."], "です không phải động từ nhóm 3; đây là trợ động từ lịch sự.", ["だ", "は"]),
	g$1(2, "だ", "Danh từ / tính từ -na + だ", "Là (thể ngắn, thân mật)", "だ dùng trong hội thoại thân mật hoặc khi trích dẫn. Tính từ -i không thêm だ. Phủ định thể ngắn của danh từ là じゃない / ではない.", [{
		jp: "これは本だ。",
		kana: "これはほんだ。",
		romaji: "Kore wa hon da.",
		vi: "Đây là sách."
	}, {
		jp: "明日は雨だ。",
		kana: "あしたはあめだ。",
		romaji: "Ashita wa ame da.",
		vi: "Ngày mai trời mưa."
	}], ["Không gắn だ sau tính từ -i: sai 高いだ, đúng 高い.", "Trong câu lịch sự với người lạ, ưu tiên です hơn だ."], "Khi kể chuyện hoặc viết nhật ký, だ xuất hiện nhiều hơn です.", ["です"]),
	g$1(3, "は", "Chủ đề + は + vị ngữ", "Đánh dấu chủ đề của câu (đọc wa)", "は không nhất thiết là chủ ngữ ngữ pháp. Nó giới thiệu điều người nói muốn nói về. Viết は nhưng đọc wa. Có thể đối lập: お茶は飲みますが、コーヒーは飲みません。", [
		{
			jp: "私はベトナム人です。",
			kana: "わたしはベトナムじんです。",
			romaji: "Watashi wa Betonamujin desu.",
			vi: "Tôi là người Việt Nam."
		},
		{
			jp: "この店は安いです。",
			kana: "このみせはやすいです。",
			romaji: "Kono mise wa yasui desu.",
			vi: "Cửa hàng này rẻ."
		},
		{
			jp: "魚は食べますが、肉は食べません。",
			kana: "さかなはたべますが、にくはたべません。",
			romaji: "Sakana wa tabemasu ga, niku wa tabemasen.",
			vi: "Cá thì tôi ăn, thịt thì không."
		}
	], ["Đừng nhầm は với が: は là chủ đề, が nhấn mạnh chủ thể mới hoặc thông tin chưa biết.", "Không đọc ha khi làm trợ từ."], "Trong câu có は, phần sau は mới là thông tin người nghe cần.", ["が", "も"]),
	g$1(4, "も", "Danh từ + も", "Cũng / nữa", "も thay cho は hoặc が khi muốn nói 'cũng vậy'. Có thể dùng với thời gian hoặc số lượng: 十年も待った (đợi tới mười năm).", [{
		jp: "私も学生です。",
		kana: "わたしもがくせいです。",
		romaji: "Watashi mo gakusei desu.",
		vi: "Tôi cũng là học sinh."
	}, {
		jp: "日本語も英語も勉強します。",
		kana: "にほんごもえいごもべんきょうします。",
		romaji: "Nihongo mo eigo mo benkyou shimasu.",
		vi: "Tôi học cả tiếng Nhật lẫn tiếng Anh."
	}], ["Không nói 私はも学生です。 も thay は chứ không đứng cạnh は.", "Với tân ngữ: 水も飲みます, không cần をも trong N5."], void 0, ["は"]),
	g$1(5, "を", "Tân ngữ + を + động từ tha động", "Đánh dấu đối tượng trực tiếp (đọc o)", "を chỉ thứ bị tác động: ăn gì, đọc gì, mua gì. Một số động từ chuyển động cũng dùng を cho nơi đi qua: 公園を歩きます.", [
		{
			jp: "りんごを食べます。",
			kana: "りんごをたべます。",
			romaji: "Ringo o tabemasu.",
			vi: "Tôi ăn táo."
		},
		{
			jp: "本を読みます。",
			kana: "ほんをよみます。",
			romaji: "Hon o yomimasu.",
			vi: "Tôi đọc sách."
		},
		{
			jp: "川の近くを歩きます。",
			kana: "かわのちかくをあるきます。",
			romaji: "Kawa no chikaku o arukimasu.",
			vi: "Tôi đi bộ gần sông."
		}
	], ["Động từ tự động như あります / います không dùng を.", "Đọc o, không đọc wo trong tiếng hiện đại."], void 0, ["に", "が"]),
	g$1(6, "に", "Thời điểm / đích / người nhận + に", "Tại (thời điểm), tới (đích), cho (người nhận)", "に dùng cho thời điểm cụ thể (三時に), điểm đến của 行く/来る/いる, vị trí tồn tại, và người nhận của あげる/もらう.", [
		{
			jp: "七時に起きます。",
			kana: "しちじにおきます。",
			romaji: "Shichiji ni okimasu.",
			vi: "Tôi dậy lúc bảy giờ."
		},
		{
			jp: "学校に行きます。",
			kana: "がっこうにいきます。",
			romaji: "Gakkou ni ikimasu.",
			vi: "Tôi đến trường."
		},
		{
			jp: "机の上に本があります。",
			kana: "つくえのうえにほんがあります。",
			romaji: "Tsukue no ue ni hon ga arimasu.",
			vi: "Trên bàn có sách."
		}
	], ["Không dùng に với khoảng thời gian mơ hồ như 毎日, 今日 (trừ khi nhấn mạnh).", "Nhầm に và で: tồn tại dùng に, hành động xảy ra dùng で."], "に và へ đều chỉ hướng đi; に nhấn đích, へ nhấn hướng.", ["で", "へ"]),
	g$1(7, "で", "Nơi hành động / phương tiện / nguyên nhân + で", "Ở (nơi diễn ra hành động), bằng (phương tiện), vì", "で chỉ nơi hành động xảy ra, khác に của tồn tại. Cũng chỉ phương tiện (バスで), chất liệu, phạm vi, nguyên nhân đơn giản (病気で休みます).", [
		{
			jp: "図書館で勉強します。",
			kana: "としょかんでべんきょうします。",
			romaji: "Toshokan de benkyou shimasu.",
			vi: "Tôi học ở thư viện."
		},
		{
			jp: "電車で会社へ行きます。",
			kana: "でんしゃでかいしゃへいきます。",
			romaji: "Densha de kaisha e ikimasu.",
			vi: "Tôi đi làm bằng tàu điện."
		},
		{
			jp: "この店でパンを買いました。",
			kana: "このみせでパンをかいました。",
			romaji: "Kono mise de pan o kaimashita.",
			vi: "Tôi đã mua bánh mì ở cửa hàng này."
		}
	], ["いる/ある chỉ vị trí thì dùng に, không dùng で.", "Không nói 学校で行きます khi muốn nói 'đi đến trường' — dùng に/へ."], void 0, ["に", "へ"]),
	g$1(8, "へ", "Hướng + へ + động từ chuyển động", "Về phía / tới (đọc e)", "へ nhấn hướng đi hơn là đích chính xác. Thường đi với 行く, 来る, 帰る. Có thể viết へ nhưng đọc e.", [{
		jp: "海へ行きます。",
		kana: "うみへいきます。",
		romaji: "Umi e ikimasu.",
		vi: "Tôi đi biển."
	}, {
		jp: "家へ帰ります。",
		kana: "いえへかえります。",
		romaji: "Ie e kaerimasu.",
		vi: "Tôi về nhà."
	}], ["Đọc e, không đọc he khi là trợ từ.", "Không dùng へ với います/あります."], "Trong N5, に và へ thường thay thế được với động từ đi/đến.", ["に"]),
	g$1(9, "の", "Danh từ 1 + の + danh từ 2", "Của / thuộc / bổ nghĩa danh từ", "の nối hai danh từ: sở hữu (私の本), loại (日本語の先生), vị trí (駅の前). Có thể lặp の nhưng tránh chuỗi quá dài.", [
		{
			jp: "これは私の辞書です。",
			kana: "これはわたしのじしょです。",
			romaji: "Kore wa watashi no jisho desu.",
			vi: "Đây là từ điển của tôi."
		},
		{
			jp: "駅の前で待ちます。",
			kana: "えきのまえでまちます。",
			romaji: "Eki no mae de machimasu.",
			vi: "Tôi đợi trước nhà ga."
		},
		{
			jp: "田中さんの自転車です。",
			kana: "たなかさんのじてんしゃです。",
			romaji: "Tanaka-san no jitensha desu.",
			vi: "Đây là xe đạp của anh Tanaka."
		}
	], ["Không dùng の giữa tính từ -i và danh từ: sai 高いの本, đúng 高い本.", "の cũng có thể thay danh từ đã nêu: 赤いのが欲しいです."], void 0, ["は"]),
	g$1(10, "と", "A と B / danh từ + と + động từ", "Và (liệt kê) / cùng với / rằng", "と nối danh từ ngang hàng (パンと牛乳). Cũng nghĩa 'cùng với ai' (友達と話す). Ở N5 chưa cần nghĩa trích dẫn と言う.", [{
		jp: "卵と牛乳を買います。",
		kana: "たまごとぎゅうにゅうをかいます。",
		romaji: "Tamago to gyuunyuu o kaimasu.",
		vi: "Tôi mua trứng và sữa."
	}, {
		jp: "妹と公園へ行きます。",
		kana: "いもうととこうえんへいきます。",
		romaji: "Imouto to kouen e ikimasu.",
		vi: "Tôi đi công viên với em gái."
	}], ["と liệt kê đầy đủ; nếu danh sách mở thì dùng や.", "Không nối hai động từ bằng と theo nghĩa 'và rồi' — dùng dạng て."], void 0, ["も"]),
	g$1(11, "が", "Chủ thể + が + vị ngữ", "Đánh dấu chủ thể / thông tin mới / đối tượng của 好き・分かる", "が chỉ người hoặc vật thực hiện hành động, hoặc thứ vừa xuất hiện. Với 好き, 嫌い, 分かる, いる, ある, đối tượng thường mang が.", [
		{
			jp: "あそこに猫がいます。",
			kana: "あそこにねこがいます。",
			romaji: "Asoko ni neko ga imasu.",
			vi: "Ở đằng kia có một con mèo."
		},
		{
			jp: "日本語が好きです。",
			kana: "にほんごがすきです。",
			romaji: "Nihongo ga suki desu.",
			vi: "Tôi thích tiếng Nhật."
		},
		{
			jp: "雨が降っています。",
			kana: "あめがふっています。",
			romaji: "Ame ga futte imasu.",
			vi: "Trời đang mưa."
		}
	], ["Đừng luôn thay が bằng は. Câu 'có cái gì đó' dùng が.", "好きです đi với が, không phải を."], void 0, ["は", "を"]),
	g$1(12, "か", "Câu + か", "Nghi vấn / hay (lựa chọn)", "Thêm か cuối câu lịch sự để hỏi, không cần dấu hỏi. AかBか cho lựa chọn. Từ nghi vấn vẫn cần か ở cuối.", [{
		jp: "今、何時ですか。",
		kana: "いま、なんじですか。",
		romaji: "Ima, nanji desu ka.",
		vi: "Bây giờ là mấy giờ?"
	}, {
		jp: "お茶にしますか、コーヒーにしますか。",
		kana: "おちゃにしますか、コーヒーにしますか。",
		romaji: "Ocha ni shimasu ka, koohii ni shimasu ka.",
		vi: "Bạn dùng trà hay cà phê?"
	}], ["Trong câu lịch sự không bỏ か nếu muốn rõ ràng là câu hỏi.", "Không dùng か và ね chồng lên nhau với nghĩa hỏi xác nhận — chọn một."], void 0, ["ね/よ"]),
	g$1(13, "ね / よ", "Câu + ね / よ", "ね: xác nhận, chia sẻ; よ: thông báo, nhấn mạnh", "ね kéo người nghe đồng tình, giống 'nhỉ'. よ đưa thông tin người nghe chưa biết, giống 'đấy / nhé'. Có thể よね khi vừa thông báo vừa xin đồng tình.", [{
		jp: "今日は暑いですね。",
		kana: "きょうはあついですね。",
		romaji: "Kyou wa atsui desu ne.",
		vi: "Hôm nay nóng nhỉ."
	}, {
		jp: "この店は安いですよ。",
		kana: "このみせはやすいですよ。",
		romaji: "Kono mise wa yasui desu yo.",
		vi: "Cửa hàng này rẻ đấy."
	}], ["Dùng よ với người trên khi chưa chắc họ muốn nghe lời khuyên có thể hơi mạnh.", "ね không biến câu thành câu hỏi か."], void 0, ["か"]),
	g$1(14, "これ / それ / あれ", "これ / それ / あれ + は + danh từ + です", "Cái này / cái đó / cái kia (đại từ chỉ định)", "これ gần người nói, それ gần người nghe, あれ xa cả hai. Chúng đứng một mình, không đi kèm danh từ.", [
		{
			jp: "これは私の傘です。",
			kana: "これはわたしのかさです。",
			romaji: "Kore wa watashi no kasa desu.",
			vi: "Đây là ô của tôi."
		},
		{
			jp: "それは何ですか。",
			kana: "それはなんですか。",
			romaji: "Sore wa nan desu ka.",
			vi: "Đó là gì?"
		},
		{
			jp: "あれは銀行です。",
			kana: "あれはぎんこうです。",
			romaji: "Are wa ginkou desu.",
			vi: "Kia là ngân hàng."
		}
	], ["Không nói これ本です. Phải これは本です hoặc この本です.", "どれ dùng khi hỏi lựa chọn trong nhóm."], void 0, ["この/その/あの"]),
	g$1(15, "この / その / あの", "この / その / あの + danh từ", "Này / đó / kia (đi với danh từ)", "Khác これ/それ/あれ, bộ này luôn cần danh từ theo sau. どの + danh từ để hỏi 'nào'.", [
		{
			jp: "この本は面白いです。",
			kana: "このほんはおもしろいです。",
			romaji: "Kono hon wa omoshiroi desu.",
			vi: "Quyển sách này thú vị."
		},
		{
			jp: "その人は先生です。",
			kana: "そのひとはせんせいです。",
			romaji: "Sono hito wa sensei desu.",
			vi: "Người đó là giáo viên."
		},
		{
			jp: "あの山は高いです。",
			kana: "あのやまはたかいです。",
			romaji: "Ano yama wa takai desu.",
			vi: "Ngọn núi kia cao."
		}
	], ["Sai: このは本です. Đúng: これは本です hoặc この本です.", "この không đứng một mình."], void 0, ["これ/それ/あれ"]),
	g$1(16, "ます", "Thân động từ (ます-stem) + ます", "Thể lịch sự hiện tại / tương lai (khẳng định)", "ます diễn tả thói quen hoặc hành động sẽ xảy ra, giọng lịch sự. Không mang thông tin quá khứ. Động từ nhóm 1/2/3 đều gắn ます vào thân ます.", [{
		jp: "毎日日本語を勉強します。",
		kana: "まいにちにほんごをべんきょうします。",
		romaji: "Mainichi nihongo o benkyou shimasu.",
		vi: "Tôi học tiếng Nhật mỗi ngày."
	}, {
		jp: "明日公園へ行きます。",
		kana: "あしたこうえんへいきます。",
		romaji: "Ashita kouen e ikimasu.",
		vi: "Ngày mai tôi đến công viên."
	}], ["Không thêm です sau ます.", "する → します, 来る → きます, 行く → いきます."], "Thể ます không chia ngôi.", ["ません", "ました"]),
	g$1(17, "ません", "Thân ます + ません", "Thể lịch sự phủ định hiện tại / tương lai", "ません là phủ định của ます. Dùng khi nói không làm / sẽ không làm một cách lịch sự.", [{
		jp: "肉は食べません。",
		kana: "にくはたべません。",
		romaji: "Niku wa tabemasen.",
		vi: "Tôi không ăn thịt."
	}, {
		jp: "今日は会社へ行きません。",
		kana: "きょうはかいしゃへいきません。",
		romaji: "Kyou wa kaisha e ikimasen.",
		vi: "Hôm nay tôi không đến công ty."
	}], ["Không viết ますせん.", "Quá khứ phủ định là ませんでした, không phải ませんだった."], void 0, ["ます", "ない"]),
	g$1(18, "ました", "Thân ます + ました / ませんでした", "Thể lịch sự quá khứ (khẳng định / phủ định)", "ました nói việc đã xảy ra. Phủ định quá khứ lịch sự: ませんでした. Thời gian thường có 昨日, 先週, 去年.", [{
		jp: "昨日映画を見ました。",
		kana: "きのうえいがをみました。",
		romaji: "Kinou eiga o mimashita.",
		vi: "Hôm qua tôi xem phim."
	}, {
		jp: "朝ごはんを食べませんでした。",
		kana: "あさごはんをたべませんでした。",
		romaji: "Asagohan o tabemasen deshita.",
		vi: "Tôi đã không ăn sáng."
	}], ["Không dùng ました với 毎日 nếu đang nói thói quen hiện tại.", "Phủ định không phải ましたせん."], void 0, ["ます", "かった"]),
	g$1(19, "て-form", "Động từ → dạng て", "Dạng nối: yêu cầu, nối hành động, trạng thái", "Dạng て là cửa ngõ nhiều mẫu N5: てください, ています, てもいい. Nhóm 1 biến âm (う→って, む→んで, く→いて trừ 行く→行って). Nhóm 2: bỏ る thêm て. する→して, 来る→きて.", [{
		jp: "名前を書いて、座ってください。",
		kana: "なまえをかいて、すわってください。",
		romaji: "Namae o kaite, suwatte kudasai.",
		vi: "Hãy viết tên rồi ngồi xuống."
	}, {
		jp: "朝ごはんを食べて、学校へ行きます。",
		kana: "あさごはんをたべて、がっこうへいきます。",
		romaji: "Asagohan o tabete, gakkou e ikimasu.",
		vi: "Tôi ăn sáng rồi đến trường."
	}], ["行く là 行って, không phải 行いて.", "Nhóm 1 ぐ → いで (泳ぐ→泳いで)."], "Hãy thuộc bảng biến âm nhóm 1 trước khi học ている.", ["てください", "ている"]),
	g$1(20, "ている", "Động từ dạng て + いる / います", "Đang làm / kết quả còn lại / thói quen", "ている có ba sắc thái: hành động đang diễn ra (食べている), kết quả còn đó (結婚している, 窓が開いている), thói quen (毎朝走っている). Lịch sự: ています.", [
		{
			jp: "今、本を読んでいます。",
			kana: "いま、ほんをよんでいます。",
			romaji: "Ima, hon o yonde imasu.",
			vi: "Bây giờ tôi đang đọc sách."
		},
		{
			jp: "兄は会社で働いています。",
			kana: "あにはかいしゃではたらいています。",
			romaji: "Ani wa kaisha de hataraite imasu.",
			vi: "Anh trai đang làm việc ở công ty."
		},
		{
			jp: "窓が開いています。",
			kana: "まどがあいています。",
			romaji: "Mado ga aite imasu.",
			vi: "Cửa sổ đang mở."
		}
	], ["Không nhầm mọi ている đều là 'đang'. 知っています nghĩa là 'biết' (kết quả).", "Phủ định: ていません, không phải ているません."], void 0, ["て-form"]),
	g$1(21, "たい", "Thân ます + たいです", "Muốn làm", "たい biến động từ thành tính từ -i nghĩa 'muốn'. Tân ngữ thường đổi を thành が, dù を vẫn gặp. Phủ định: たくない. Quá khứ: たかった.", [{
		jp: "水が飲みたいです。",
		kana: "みずがのみたいです。",
		romaji: "Mizu ga nomitai desu.",
		vi: "Tôi muốn uống nước."
	}, {
		jp: "来年日本へ行きたいです。",
		kana: "らいねんにほんへいきたいです。",
		romaji: "Rainen Nihon e ikitai desu.",
		vi: "Năm sau tôi muốn đi Nhật."
	}], ["たい nói mong muốn của người nói; hỏi người khác thì nhẹ nhàng hơn, tránh ép.", "Không gắn たい vào です."], "Muốn người khác làm gì thì không dùng たい mà dùng てほしい (N4).", ["ます"]),
	g$1(22, "ませんか", "Thân ます + ませんか", "Mời / rủ một cách lịch sự", "ませんか dùng để rủ người nghe cùng làm, lịch sự hơn ましょう. Không phải lúc nào cũng là câu hỏi phủ định theo nghĩa Việt.", [{
		jp: "一緒に昼ごはんを食べませんか。",
		kana: "いっしょにひるごはんをたべませんか。",
		romaji: "Issho ni hirugohan o tabemasen ka.",
		vi: "Cùng ăn trưa nhé?"
	}, {
		jp: "お茶を飲みませんか。",
		kana: "おちゃをのみませんか。",
		romaji: "Ocha o nomimasen ka.",
		vi: "Bạn uống trà chứ?"
	}], ["Đừng dịch sát 'không ăn à?' rồi trả lời lệch. Đây là lời mời.", "Trả lời nhận lời: ええ、しましょう / はい、ぜひ."], void 0, ["ましょう", "ません"]),
	g$1(23, "ましょう", "Thân ます + ましょう", "Hãy cùng... / tôi sẽ... (đề nghị)", "ましょう vừa rủ cùng làm, vừa bày tỏ ý định lịch sự của người nói (私が持ちましょう). ましょうか là 'tôi làm giúp chứ?'.", [{
		jp: "駅まで歩きましょう。",
		kana: "えきまであるきましょう。",
		romaji: "Eki made arukimashou.",
		vi: "Mình đi bộ tới ga nhé."
	}, {
		jp: "窓を開けましょうか。",
		kana: "まどをあけましょうか。",
		romaji: "Mado o akemashou ka.",
		vi: "Tôi mở cửa sổ giúp nhé?"
	}], ["Không dùng ましょう để ra lệnh một phía với người trên.", "Khác ませんか: ましょう hơi chủ động hơn."], void 0, ["ませんか"]),
	g$1(24, "てください", "Động từ dạng て + ください", "Hãy làm... (yêu cầu lịch sự)", "てください là cách nhờ lịch sự cơ bản. Phủ định: ないでください. Có thể kèm ちょっと để mềm hơn.", [
		{
			jp: "ゆっくり話してください。",
			kana: "ゆっくりはなしてください。",
			romaji: "Yukkuri hanashite kudasai.",
			vi: "Hãy nói chậm giúp tôi."
		},
		{
			jp: "ここで待ってください。",
			kana: "ここでまってください。",
			romaji: "Koko de matte kudasai.",
			vi: "Hãy đợi ở đây."
		},
		{
			jp: "ドアを閉めないでください。",
			kana: "ドアをしめないでください。",
			romaji: "Doa o shimenaide kudasai.",
			vi: "Xin đừng đóng cửa."
		}
	], ["Không dùng ますてください.", "Với người lạ, thêm すみません trước cho lịch sự."], void 0, ["て-form"]),
	g$1(25, "ない", "Động từ thể ない / tính từ -i: 〜くない", "Phủ định thể ngắn", "Thể ない là phủ định thân mật, cũng là gốc của ないでください, なければならない. Tính từ -i: 高くない. Danh từ/na: じゃない.", [{
		jp: "今日は行かない。",
		kana: "きょうはいかない。",
		romaji: "Kyou wa ikanai.",
		vi: "Hôm nay tôi không đi."
	}, {
		jp: "この本は高くないです。",
		kana: "このほんはたかくないです。",
		romaji: "Kono hon wa takakunai desu.",
		vi: "Quyển sách này không đắt."
	}], ["ある phủ định là ない, không phải あらない.", "いい phủ định là よくない, không phải いくない."], void 0, ["ません", "かった"]),
	g$1(26, "かった", "Tính từ -i (bỏ い) + かったです", "Quá khứ của tính từ -i", "高い → 高かった. Phủ định quá khứ: 高くなかった. Tính từ -na và danh từ dùng でした / じゃなかったです.", [{
		jp: "昨日は寒かったです。",
		kana: "きのうはさむかったです。",
		romaji: "Kinou wa samukatta desu.",
		vi: "Hôm qua trời lạnh."
	}, {
		jp: "試験は難しくなかったです。",
		kana: "しけんはむずかしくなかったです。",
		romaji: "Shiken wa muzukashiku nakatta desu.",
		vi: "Kỳ thi không khó."
	}], ["Sai: 寒いでした. Đúng: 寒かったです.", "Sai: 高かったじゃないです cho phủ định quá khứ -i."], void 0, ["ない", "ました"]),
	g$1(27, "がある / いる", "Nơi + に + chủ thể + が あります / います", "Có (vật) / có (người, động vật)", "あります cho đồ vật, thực vật, sự kiện. います cho người, động vật, côn trùng. Vị trí dùng に. Câu hỏi: 何がありますか / 誰がいますか.", [{
		jp: "机の上に辞書があります。",
		kana: "つくえのうえにじしょがあります。",
		romaji: "Tsukue no ue ni jisho ga arimasu.",
		vi: "Trên bàn có từ điển."
	}, {
		jp: "公園に子供がいます。",
		kana: "こうえんにこどもがいます。",
		romaji: "Kouen ni kodomo ga imasu.",
		vi: "Ở công viên có trẻ em."
	}], ["Không dùng います cho ghế, sách, xe.", "Sự kiện (lễ hội, kỳ thi) dùng あります."], void 0, ["に", "が"]),
	g$1(28, "もう / まだ", "もう + quá khứ / まだ + phủ định hoặc ている", "もう: đã rồi / nữa; まだ: vẫn còn / chưa", "もう食べました = đã ăn rồi. まだ食べていません = chưa ăn. まだ雨が降っています = mưa vẫn còn. もう một nghĩa khác là 'thêm': もう一つ.", [
		{
			jp: "宿題はもう終わりました。",
			kana: "しゅくだいはもうおわりました。",
			romaji: "Shukudai wa mou owarimashita.",
			vi: "Bài tập đã xong rồi."
		},
		{
			jp: "まだ雨が降っています。",
			kana: "まだあめがふっています。",
			romaji: "Mada ame ga futte imasu.",
			vi: "Mưa vẫn đang rơi."
		},
		{
			jp: "兄はまだ帰っていません。",
			kana: "あにはまだかえっていません。",
			romaji: "Ani wa mada kaette imasen.",
			vi: "Anh trai vẫn chưa về."
		}
	], ["もう + phủ định nghĩa là 'không còn': もうありません.", "Không nói もうまだ cùng lúc."], void 0, ["ている"]),
	g$1(29, "から / まで", "A から B まで", "Từ ... đến ...", "から là điểm bắt đầu (thời gian hoặc nơi). まで là điểm kết. Có thể dùng riêng. から cũng có nghĩa 'vì' khi đứng sau câu (N5–N4).", [{
		jp: "九時から五時まで働きます。",
		kana: "くじからごじまではたらきます。",
		romaji: "Kuji kara goji made hatarakimasu.",
		vi: "Tôi làm từ chín giờ đến năm giờ."
	}, {
		jp: "家から駅まで歩きます。",
		kana: "いえからえきまであるきます。",
		romaji: "Ie kara eki made arukimasu.",
		vi: "Tôi đi bộ từ nhà tới ga."
	}], ["Không dùng に thay から cho điểm xuất phát của khoảng.", "まで không mang nghĩa 'cho đến khi hoàn thành' như までに (N4)."], void 0, ["に"]),
	g$1(30, "前に", "Danh từ + の前に / động từ thể từ điển + 前に", "Trước khi ...", "前に chỉ hành động xảy ra trước một mốc. Với danh từ thêm の. Động từ giữ thể từ điển, không chia quá khứ dù sự việc đã xảy ra.", [{
		jp: "寝る前に本を読みます。",
		kana: "ねるまえにほんをよみます。",
		romaji: "Neru mae ni hon o yomimasu.",
		vi: "Trước khi ngủ tôi đọc sách."
	}, {
		jp: "食事の前に手を洗います。",
		kana: "しょくじのまえにてをあらいます。",
		romaji: "Shokuji no mae ni te o araimasu.",
		vi: "Trước bữa ăn tôi rửa tay."
	}], ["Sai: 寝た前に. Đúng: 寝る前に.", "Khác てから: てから nhấn 'sau khi A thì B'."], void 0, ["から/まで"])
];
function g(n, name, structure, meaning_vi, usage, examples, mistakes, notes, related) {
	return {
		id: `g-n4-${String(n).padStart(2, "0")}`,
		name,
		structure,
		meaning_vi,
		usage,
		level: "N4",
		examples,
		mistakes,
		notes,
		related
	};
}
var GRAMMAR_N4 = [
	g(1, "と思う", "Câu thể ngắn + と思う / 思います", "Tôi nghĩ rằng ...", "Đặt thể ngắn (だ / た / ない / い) trước と思う để nêu suy nghĩ. Với danh từ và tính từ -na dùng だと思う. Muốn mềm hơn: と思います.", [
		{
			jp: "明日は雨だと思う。",
			kana: "あしたはあめだとおもう。",
			romaji: "Ashita wa ame da to omou.",
			vi: "Tôi nghĩ ngày mai trời mưa."
		},
		{
			jp: "この問題は難しいと思います。",
			kana: "このもんだいはむずかしいとおもいます。",
			romaji: "Kono mondai wa muzukashii to omoimasu.",
			vi: "Tôi nghĩ bài này khó."
		},
		{
			jp: "彼はもう着いたと思います。",
			kana: "かれはもうついたとおもいます。",
			romaji: "Kare wa mou tsuita to omoimasu.",
			vi: "Tôi nghĩ anh ấy đã đến rồi."
		}
	], ["Không để thể ます ngay trước と思う: sai 行きますと思う, đúng 行くと思う.", "Danh từ cần だ: sai 学生と思う, đúng 学生だと思う."], "と思う nói ý kiến người nói; と言っている thuật lại lời người khác.", ["そうだ (hearsay)"]),
	g(2, "つもり", "Động từ thể từ điển / ない + つもりだ", "Dự định / ý định", "つもり nói kế hoạch đã có trong đầu người nói. Phủ định ý định: ないつもり. Đã không làm điều dự định: つもりだった (nhưng thực tế khác).", [{
		jp: "来年日本へ行くつもりです。",
		kana: "らいねんにほんへいくつもりです。",
		romaji: "Rainen Nihon e iku tsumori desu.",
		vi: "Tôi định năm sau đi Nhật."
	}, {
		jp: "今夜は外で食べないつもりです。",
		kana: "こんやはそとでたべないつもりです。",
		romaji: "Kon'ya wa soto de tabenai tsumori desu.",
		vi: "Tối nay tôi không định ăn ngoài."
	}], ["Không gắn ます: sai 行きますつもり.", "Khác たい: たい là muốn, つもり là đã định."], void 0, ["たい", "予定"]),
	g(3, "ようだ", "Thể ngắn + ようだ / のような / のように", "Hình như / giống như (suy đoán dựa trên cảm nhận)", "ようだ diễn tả phán đoán dựa trên những gì thấy, nghe, cảm nhận. のようだ sau danh từ. のように chỉ cách thức 'như là'.", [
		{
			jp: "今日は雨のようです。",
			kana: "きょうはあめのようです。",
			romaji: "Kyou wa ame no you desu.",
			vi: "Hôm nay hình như trời mưa."
		},
		{
			jp: "彼は疲れたようです。",
			kana: "かれはつかれたようです。",
			romaji: "Kare wa tsukareta you desu.",
			vi: "Trông anh ấy có vẻ mệt."
		},
		{
			jp: "子供のように走っています。",
			kana: "こどものようにはしっています。",
			romaji: "Kodomo no you ni hashitte imasu.",
			vi: "Người ấy chạy như trẻ con."
		}
	], ["Sau danh từ cần のようだ, không phải ようだ trực tiếp.", "Đừng nhầm với ように (để sao cho) — khác chức năng."], void 0, ["らしい", "そうだ (hearsay)"]),
	g(4, "らしい", "Thể ngắn / danh từ + らしい", "Nghe đâu / đúng chất (suy đoán khách quan hoặc đặc trưng)", "らしい vừa là tin đồn dựa trên thông tin gián tiếp, vừa nghĩa 'đúng kiểu A' (学生らしい服装). Không chia だ trước らしい.", [{
		jp: "明日は雪らしいです。",
		kana: "あしたはゆきらしいです。",
		romaji: "Ashita wa yuki rashii desu.",
		vi: "Nghe đâu ngày mai có tuyết."
	}, {
		jp: "彼は先生らしい話し方をします。",
		kana: "かれはせんせいらしいはなしかたをします。",
		romaji: "Kare wa sensei rashii hanashikata o shimasu.",
		vi: "Anh ấy nói chuyện đúng kiểu giáo viên."
	}], ["Không nói 学生だらしい.", "らしい không dùng khi tự mình nhìn thấy rõ — lúc đó dùng ようだ."], void 0, ["ようだ", "そうだ (hearsay)"]),
	g(5, "そうだ (nghe nói)", "Thể ngắn + そうだ", "Nghe nói rằng ... (truyền đạt tin)", "Đây là そうだ truyền tin, khác 美味しそう (trông có vẻ). Phải dùng thể ngắn: だそうだ với danh từ. Người nói không tự suy, chỉ thuật lại.", [{
		jp: "田中さんは来月結婚するそうです。",
		kana: "たなかさんはらいげつけっこんするそうです。",
		romaji: "Tanaka-san wa raigetsu kekkon suru sou desu.",
		vi: "Nghe nói anh Tanaka tháng sau kết hôn."
	}, {
		jp: "駅前に新しい店ができたそうです。",
		kana: "えきまえにあたらしいみせができたそうです。",
		romaji: "Ekimae ni atarashii mise ga dekita sou desu.",
		vi: "Nghe nói trước ga có cửa hàng mới."
	}], ["Không nhầm với 〜そう (vẻ bề ngoài): 美味しそうは 'trông ngon', 美味しいそうは sai.", "Danh từ: 学生だそうです, không phải 学生そうです."], "Khi viết, ngữ cảnh quyết định đây là hearsay chứ không phải 'trông có vẻ'.", ["と思う", "らしい"]),
	g(6, "てしまう", "Động từ dạng て + しまう / しまいます", "Làm xong / lỡ làm (tiếc nuối)", "てしまう có hai sắc: hoàn tất (宿題をやってしまった) và sự cố đáng tiếc (忘れてしまった). Hội thoại thường rút てしまう→ちゃう / じゃう.", [{
		jp: "宿題を全部やってしまいました。",
		kana: "しゅくだいをぜんぶやってしまいました。",
		romaji: "Shukudai o zenbu yatte shimaimashita.",
		vi: "Tôi đã làm hết bài tập rồi."
	}, {
		jp: "電車の中で傘を忘れてしまいました。",
		kana: "でんしゃのなかでかさをわすれてしまいました。",
		romaji: "Densha no naka de kasa o wasurete shimaimashita.",
		vi: "Tôi lỡ quên ô trên tàu."
	}], ["Không phải lúc nào cũng tiêu cực; ngữ cảnh quyết định.", "Nhóm ぐ/む/ぶ: でしまう (読んでしまう)."], void 0, ["ておく", "てみる"]),
	g(7, "ておく", "Động từ dạng て + おく / おきます", "Làm sẵn / để đó (chuẩn bị)", "ておく nói hành động làm trước để phục vụ việc sau, hoặc để nguyên trạng thái. Hội thoại: とく.", [{
		jp: "旅行の前に切符を買っておきます。",
		kana: "りょこうのまえにきっぷをかっておきます。",
		romaji: "Ryokou no mae ni kippu o katte okimasu.",
		vi: "Trước chuyến đi tôi mua vé sẵn."
	}, {
		jp: "窓を開けておいてください。",
		kana: "まどをあけておいてください。",
		romaji: "Mado o akete oite kudasai.",
		vi: "Hãy để cửa sổ mở sẵn."
	}], ["Khác てしまう: ておく là chủ động chuẩn bị, không phải lỡ tay.", "Không dùng với hành động không có ý chuẩn bị."], void 0, ["てしまう", "前に"]),
	g(8, "てみる", "Động từ dạng て + みる / みます", "Thử làm xem", "てみる là làm để xem kết quả thế nào, không phải 見る 'nhìn'. Hay đi với lời khuyên: やってみたらどうですか.", [{
		jp: "この靴を履いてみてもいいですか。",
		kana: "このくつをはいてみてもいいですか。",
		romaji: "Kono kutsu o haite mite mo ii desu ka.",
		vi: "Tôi thử đôi giày này được không?"
	}, {
		jp: "日本語で手紙を書いてみます。",
		kana: "にほんごでてがみをかいてみます。",
		romaji: "Nihongo de tegami o kaite mimasu.",
		vi: "Tôi sẽ thử viết thư bằng tiếng Nhật."
	}], ["Không dịch lúc nào cũng là 'nhìn'.", "Phủ định thử: てみない / てみません."], void 0, ["たらどう", "てしまう"]),
	g(9, "ば (điều kiện)", "Động từ / tính từ dạng ば", "Nếu ... thì ... (điều kiện giả định)", "Nhóm 1: う→えば (行く→行けば). Nhóm 2: れば (食べる→食べれば). する→すれば, 来る→くれば. Tính từ -i: ければ. Danh từ/na: なら (thường học riêng).", [{
		jp: "時間があれば、海へ行きます。",
		kana: "じかんがあれば、うみへいきます。",
		romaji: "Jikan ga areba, umi e ikimasu.",
		vi: "Nếu có thời gian, tôi sẽ ra biển."
	}, {
		jp: "安ければ買います。",
		kana: "やすければかいます。",
		romaji: "Yasukereba kaimasu.",
		vi: "Nếu rẻ thì tôi mua."
	}], ["ある → あれば, không phải あれば lẫn あったら khi muốn nhấn tình huống cụ thể — たら tự nhiên hơn với sự việc đã xảy ra.", "Không dùng ば dễ dàng với mệnh lệnh / mời ở vế sau trong văn nói thân mật — hay dùng たら."], "Vế sau thường là phán đoán, kết quả tự nhiên, không phải mệnh lệnh mạnh.", ["たら", "なら"]),
	g(10, "たら", "Thể quá khứ ngắn + ら", "Nếu / khi (sau khi A thì B)", "たら dùng rộng: điều kiện, 'khi đã...', phát hiện bất ngờ (窓を開けたら山が見えた). Dễ dùng trong hội thoại hơn ば.", [
		{
			jp: "家へ帰ったら、手を洗います。",
			kana: "いえへかえったら、てをあらいます。",
			romaji: "Ie e kaettara, te o araimasu.",
			vi: "Về đến nhà thì tôi rửa tay."
		},
		{
			jp: "雨が降ったら、試合はありません。",
			kana: "あめがふったら、しあいはありません。",
			romaji: "Ame ga futtara, shiai wa arimasen.",
			vi: "Nếu mưa thì không có trận đấu."
		},
		{
			jp: "窓を開けたら、冷たい風が入ってきました。",
			kana: "まどをあけたら、つめたいかぜがはいってきました。",
			romaji: "Mado o aketara, tsumetai kaze ga haitte kimashita.",
			vi: "Mở cửa sổ thì gió lạnh ùa vào."
		}
	], ["たら dựa trên thể quá khứ: 行ったら, không phải 行くたら.", "Với lời khuyên dùng たらいい / たらどう."], void 0, [
		"ば",
		"なら",
		"たらどう"
	]),
	g(11, "なら", "Danh từ / thể ngắn + なら", "Nếu (là trường hợp bạn nói) / còn về A thì", "なら lấy thông tin người nghe vừa nêu làm điều kiện. Cũng dùng đối lập chủ đề: 週末なら行けます. Không cần だ trước なら.", [{
		jp: "駅前なら、あの店が安いですよ。",
		kana: "えきまえなら、あのみせがやすいですよ。",
		romaji: "Ekimae nara, ano mise ga yasui desu yo.",
		vi: "Nếu là trước ga thì cửa hàng kia rẻ đấy."
	}, {
		jp: "今行くなら、一緒に行きましょう。",
		kana: "いまいくなら、いっしょにいきましょう。",
		romaji: "Ima iku nara, issho ni ikimashou.",
		vi: "Nếu bạn đi bây giờ thì mình đi cùng."
	}], ["Không nói 学生だなら.", "なら không diễn tả phát hiện bất ngờ như たら."], void 0, ["ば", "たら"]),
	g(12, "のに", "Thể ngắn + のに", "Thế mà / mặc dù (trái mong đợi)", "のに nối hai vế trái ngược, thường có sắc nuối tiếc hoặc phàn nàn. Danh từ/na: なのに.", [{
		jp: "勉強したのに、点が低かったです。",
		kana: "べんきょうしたのに、てんがひくかったです。",
		romaji: "Benkyou shita noni, ten ga hikukatta desu.",
		vi: "Thế mà học rồi, điểm vẫn thấp."
	}, {
		jp: "安いのに、誰も買いません。",
		kana: "やすいのに、だれもかいません。",
		romaji: "Yasui noni, dare mo kaimasen.",
		vi: "Rẻ thế mà chẳng ai mua."
	}], ["Vế sau không nên là mời/rủ (hãy dùng ので hoặc から).", "Danh từ: 学生なのに, không phải 学生のに."], "Sắc thái mạnh hơn けど; cẩn thận khi nói với người trên.", ["ので", "ても"]),
	g(13, "ので", "Thể ngắn + ので (danh từ/na: なので)", "Vì ... nên ... (lý do khách quan, nhẹ nhàng)", "ので đưa lý do, lịch sự và khách quan hơn から. Hay dùng khi xin lỗi, giải thích. Lịch sự có thể ますので.", [{
		jp: "頭が痛いので、少し休みます。",
		kana: "あたまがいたいので、すこしやすみます。",
		romaji: "Atama ga itai node, sukoshi yasumimasu.",
		vi: "Vì đau đầu nên tôi nghỉ một chút."
	}, {
		jp: "雨なので、試合はありません。",
		kana: "あめなので、しあいはありません。",
		romaji: "Ame na node, shiai wa arimasen.",
		vi: "Vì mưa nên không có trận đấu."
	}], ["Danh từ cần なので, không phải ので trực tiếp.", "Vế sau ít khi là mệnh lệnh thô."], void 0, ["のに", "から"]),
	g(14, "ために", "Danh từ + のために / động từ thể từ điển + ために", "Để / vì (mục đích hoặc lợi ích)", "ために chỉ mục đích khi động từ chủ động cùng chủ ngữ, hoặc nghĩa 'vì lợi ích của'. Với tình huống ngoài ý muốn, hay dùng ように.", [{
		jp: "健康のために毎日歩きます。",
		kana: "けんこうのためにまいにちあるきます。",
		romaji: "Kenkou no tame ni mainichi arukimasu.",
		vi: "Vì sức khỏe tôi đi bộ mỗi ngày."
	}, {
		jp: "試験に合格するために勉強します。",
		kana: "しけんにごうかくするためにべんきょうします。",
		romaji: "Shiken ni goukaku suru tame ni benkyou shimasu.",
		vi: "Tôi học để đậu kỳ thi."
	}], ["Danh từ cần のために.", "Khi vế trước không chủ động (分かる, 見える) dùng ように chứ không ために."], void 0, ["ように"]),
	g(15, "ように", "Động từ thể từ điển / ない + ように", "Để sao cho / sao cho đừng / giống như", "ように dùng khi mục đích không hoàn toàn do ý chí trực tiếp (聞こえるように), lời dặn (忘れないように), hoặc so sánh (子供のように). ようにする = cố làm cho thành thói quen.", [{
		jp: "遅れないように早く出ます。",
		kana: "おくれないようにはやくでます。",
		romaji: "Okurenai you ni hayaku demasu.",
		vi: "Tôi ra sớm để không bị trễ."
	}, {
		jp: "先生が聞こえるように大きな声で話します。",
		kana: "せんせいがきこえるようにおおきなこえではなします。",
		romaji: "Sensei ga kikoeru you ni ookina koe de hanashimasu.",
		vi: "Tôi nói to để thầy nghe được."
	}], ["Đừng nhầm với ようだ suy đoán.", "ために và ように: ために cho hành động chủ động có mục tiêu rõ."], void 0, ["ために", "ようだ"]),
	g(16, "なければならない", "Thể ない (bỏ い) + ければならない / なければいけません", "Phải / cần phải", "Mẫu nghĩa vụ. Lịch sự: なければいけません / なくてはいけません. Hội thoại: なきゃ, なくちゃ. Phủ định nghĩa vụ (không cần): なくてもいい.", [{
		jp: "九時までに事務所へ行かなければなりません。",
		kana: "くじまでにじむしょへいかなければなりません。",
		romaji: "Kuji made ni jimusho e ikanakereba narimasen.",
		vi: "Tôi phải đến văn phòng trước chín giờ."
	}, {
		jp: "ここで靴を脱がなければなりません。",
		kana: "ここでくつをぬがなければなりません。",
		romaji: "Koko de kutsu o nuganakereba narimasen.",
		vi: "Ở đây phải cởi giày."
	}], ["Từ ない bỏ い rồi ければ: 行かない→行かなければ.", "ない itself: なければならない (phải có)."], "なくてはいけません gần nghĩa, hơi nhấn 'không được không làm'.", ["ても"]),
	g(17, "ても", "Dạng て + も", "Dù ... vẫn ...", "ても nêu điều kiện ngược: dù A xảy ra, B vẫn thế. Tính từ -i: くても. Danh từ/na: でも. てもいい = được phép.", [
		{
			jp: "雨が降っても行きます。",
			kana: "あめがふってもいきます。",
			romaji: "Ame ga futte mo ikimasu.",
			vi: "Dù mưa tôi vẫn đi."
		},
		{
			jp: "高くても、この本が欲しいです。",
			kana: "たかくても、このほんがほしいです。",
			romaji: "Takakute mo, kono hon ga hoshii desu.",
			vi: "Dù đắt tôi vẫn muốn cuốn này."
		},
		{
			jp: "窓を開けてもいいですか。",
			kana: "まどをあけてもいいですか。",
			romaji: "Mado o akete mo ii desu ka.",
			vi: "Tôi mở cửa sổ được không?"
		}
	], ["Khác のに: ても trung lập hơn, のに có nuối tiếc.", "いいですか đi với ても, không phải たら trong mẫu xin phép này."], void 0, ["のに", "たら"]),
	g(18, "たらどう", "Thể た + らどうですか", "Hay là ... thử? (đề xuất)", "たらどうですか khuyên nhẹ. Mềm hơn mệnh lệnh. Có thể てみたらどうですか. Không dùng khi bản thân người nói sẽ làm giúp — lúc đó dùng ましょうか.", [{
		jp: "先生に相談したらどうですか。",
		kana: "せんせいにそうだんしたらどうですか。",
		romaji: "Sensei ni soudan shitara dou desu ka.",
		vi: "Hay là hỏi ý thầy cô?"
	}, {
		jp: "少し休んだらどうですか。",
		kana: "すこしやすんだらどうですか。",
		romaji: "Sukoshi yasundara dou desu ka.",
		vi: "Hay là nghỉ một chút?"
	}], ["Tránh dùng với cấp trên theo giọng chỉ giáo.", "Không phải câu hỏi どうですか thuần về tình trạng."], void 0, ["たら", "てみる"])
];
//#endregion
export { GRAMMAR_N5 as n, GRAMMAR_N4 as t };
