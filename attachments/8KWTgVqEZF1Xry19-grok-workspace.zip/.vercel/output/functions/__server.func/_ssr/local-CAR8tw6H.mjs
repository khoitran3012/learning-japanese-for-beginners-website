import { i as romajiVariants, r as normalizeRomaji, t as hasJapanese } from "./romaji-DAIxYx-y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/local-CAR8tw6H.js
function levenshtein(a, b) {
	if (a === b) return 0;
	if (!a.length) return b.length;
	if (!b.length) return a.length;
	const row = Array.from({ length: b.length + 1 }, (_, i) => i);
	for (let i = 1; i <= a.length; i++) {
		let prev = i - 1;
		row[0] = i;
		for (let j = 1; j <= b.length; j++) {
			const tmp = row[j];
			const cost = a[i - 1] === b[j - 1] ? 0 : 1;
			row[j] = Math.min(row[j] + 1, row[j - 1] + 1, prev + cost);
			prev = tmp;
		}
	}
	return row[b.length];
}
function fuzzyScore(query, target) {
	if (!query) return 0;
	if (target === query) return 1;
	if (target.startsWith(query)) return .92;
	if (target.includes(query)) return .75;
	const sim = 1 - levenshtein(query, target) / Math.max(query.length, target.length);
	return sim > .55 ? sim * .7 : 0;
}
function vocabToDict(v) {
	return {
		id: v.id,
		kanji: v.word,
		kana: v.kana,
		romaji: v.romaji,
		meanings: v.meanings ?? [v.meaning_vi],
		part_of_speech: v.part_of_speech,
		jlpt: [v.level],
		common: v.common ?? v.difficulty <= 2,
		frequency: v.difficulty,
		pitch_accent: null,
		examples: [{
			jp: v.example_sentence,
			kana: v.example_kana,
			romaji: v.example_romaji,
			vi: v.example_meaning_vi
		}],
		tags: v.tags,
		vocabId: v.id,
		kanjiChars: [...v.word].filter((c) => /[\u4e00-\u9fff]/.test(c))
	};
}
function buildDictionary(vocab, _kanji, extra = []) {
	const map = /* @__PURE__ */ new Map();
	for (const v of vocab) map.set(v.id, vocabToDict(v));
	for (const e of extra) map.set(e.id, e);
	return [...map.values()];
}
function posMatch(entryPos, filters) {
	return entryPos.some((p) => filters.some((f) => p === f || p.startsWith(f) || p.includes(f)));
}
function searchLocal(dict, query) {
	const raw = query.q.trim();
	if (!raw) return [];
	const q = raw.toLowerCase();
	const qNorm = normalizeRomaji(q);
	const variants = romajiVariants(q);
	const jp = hasJapanese(raw);
	return dict.filter((e) => {
		if (query.jlpt && query.jlpt.length && !e.jlpt.some((l) => query.jlpt.includes(l))) return false;
		if (query.pos && query.pos.length && !posMatch(e.part_of_speech, query.pos)) return false;
		return true;
	}).map((e) => {
		let score = 0;
		const fields = [
			e.kanji,
			e.kana,
			e.romaji.toLowerCase(),
			normalizeRomaji(e.romaji),
			...e.meanings.map((m) => m.toLowerCase()),
			...e.tags
		];
		for (const f of fields) if (f === raw || f === q) score = Math.max(score, 1);
		else if (f.startsWith(q) || f.startsWith(raw)) score = Math.max(score, .94);
		else if (f.includes(q) || f.includes(raw)) score = Math.max(score, .8);
		const nRomaji = normalizeRomaji(e.romaji);
		for (const v of variants) {
			score = Math.max(score, fuzzyScore(v, nRomaji));
			if (nRomaji.startsWith(v) && v.length >= 3) score = Math.max(score, .88);
			if (e.kana.startsWith(raw) || e.kanji.startsWith(raw)) score = Math.max(score, .96);
		}
		if (!jp) for (const m of e.meanings) score = Math.max(score, fuzzyScore(q, m.toLowerCase()) * .95);
		score = Math.max(score, fuzzyScore(qNorm, nRomaji));
		if (qNorm.length >= 4 && nRomaji.startsWith(qNorm)) score = Math.max(score, .9);
		return {
			e,
			score
		};
	}).filter((x) => x.score >= .42).sort((a, b) => b.score - a.score || Number(b.e.common) - Number(a.e.common) || a.e.frequency - b.e.frequency).slice(0, query.limit ?? 40).map((x) => x.e);
}
//#endregion
export { searchLocal as n, buildDictionary as t };
