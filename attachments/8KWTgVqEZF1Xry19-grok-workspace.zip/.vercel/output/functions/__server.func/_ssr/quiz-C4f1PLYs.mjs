import { i as __toESM } from "../_runtime.mjs";
import { a as uid } from "./utils-_83nvF2z.mjs";
import { E as require_jsx_runtime, T as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-c9IIymTs.mjs";
import { n as addQuizResult } from "./storage-BOiNWlU7.mjs";
import { i as useProgress } from "./progress-DkeQVu5t.mjs";
import { n as KATAKANA, t as HIRAGANA } from "./kana-CV-aAiLY.mjs";
import { n as KANJI_N5, t as KANJI_N4 } from "./kanji-n4-Bq9tkueZ.mjs";
import { n as VOCAB_N5, t as VOCAB_N4 } from "./vocabulary-n4-Bzb_ewCa.mjs";
import { t as PageHeader } from "./page-header-BwwPPGfl.mjs";
import { n as CardContent, t as Card } from "./card-7M-NYlJ1.mjs";
import { t as Input } from "./input-D2VeMEL1.mjs";
import { r as normalizeRomaji } from "./romaji-DAIxYx-y.mjs";
import { t as SpeakButton } from "./speak-button-DDCQe5zF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-C4f1PLYs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function shuffle(arr) {
	const a = [...arr];
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[a[i], a[j]] = [a[j], a[i]];
	}
	return a;
}
function pickWrong(pool, correct, n, key) {
	const ck = key(correct);
	return shuffle(pool.filter((x) => key(x) !== ck)).slice(0, n);
}
function makeQuiz(kind, count = 10) {
	const hira = HIRAGANA.filter((k) => k.group === "gojuon");
	const kata = KATAKANA.filter((k) => k.group === "gojuon");
	kind.includes("n4") || [...VOCAB_N5, ...VOCAB_N4];
	const kanji = [...KANJI_N5, ...KANJI_N4];
	if (kind === "hira-romaji" || kind === "kata-romaji") {
		const pool = kind === "hira-romaji" ? hira : kata;
		return shuffle(pool).slice(0, count).map((c) => {
			const opts = shuffle([c, ...pickWrong(pool, c, 3, (x) => x.romaji)]);
			return {
				id: `q-${c.id}`,
				kind,
				prompt: `${c.char} = ?`,
				promptJp: c.char,
				speak: c.char,
				options: opts.map((o) => o.romaji),
				answer: opts.findIndex((o) => o.id === c.id),
				explain: `${c.char} đọc là ${c.romaji}.`
			};
		});
	}
	if (kind === "romaji-hira") return shuffle(hira).slice(0, count).map((c) => {
		const opts = shuffle([c, ...pickWrong(hira, c, 3, (x) => x.char)]);
		return {
			id: `q-r-${c.id}`,
			kind,
			prompt: `"${c.romaji}" = ?`,
			speak: c.char,
			options: opts.map((o) => o.char),
			answer: opts.findIndex((o) => o.id === c.id),
			explain: `${c.romaji} là ${c.char}.`
		};
	});
	if (kind === "listen") {
		const pool = hira;
		return shuffle(pool).slice(0, count).map((c) => {
			const opts = shuffle([c, ...pickWrong(pool, c, 3, (x) => x.char)]);
			return {
				id: `q-l-${c.id}`,
				kind,
				prompt: "Nghe và chọn chữ",
				speak: c.char,
				options: opts.map((o) => `${o.char} (${o.romaji})`),
				answer: opts.findIndex((o) => o.id === c.id),
				explain: `Bạn nghe ${c.char} (${c.romaji}).`
			};
		});
	}
	if (kind === "kanji") return shuffle(kanji).slice(0, count).map((c) => {
		const opts = shuffle([c, ...pickWrong(kanji, c, 3, (x) => x.meaning_vi)]);
		return {
			id: `q-${c.id}`,
			kind,
			prompt: `${c.character} nghĩa là?`,
			promptJp: c.character,
			speak: c.character,
			options: opts.map((o) => o.meaning_vi),
			answer: opts.findIndex((o) => o.id === c.id),
			explain: `${c.character}: ${c.meaning_vi}. On: ${c.onyomi.join(", ")}.`
		};
	});
	const vpool = VOCAB_N5;
	if (kind === "meaning-vocab") return shuffle(vpool).slice(0, count).map((c) => {
		const opts = shuffle([c, ...pickWrong(vpool, c, 3, (x) => x.word)]);
		return {
			id: `q-mv-${c.id}`,
			kind,
			prompt: `"${c.meaning_vi}" = ?`,
			options: opts.map((o) => o.word),
			answer: opts.findIndex((o) => o.id === c.id),
			explain: `${c.meaning_vi} là ${c.word} (${c.romaji}).`
		};
	});
	return shuffle(vpool).slice(0, count).map((c) => {
		const opts = shuffle([c, ...pickWrong(vpool, c, 3, (x) => x.meaning_vi)]);
		return {
			id: `q-v-${c.id}`,
			kind: "vocab-meaning",
			prompt: `${c.word} nghĩa là?`,
			promptJp: c.word,
			speak: c.word,
			options: opts.map((o) => o.meaning_vi),
			answer: opts.findIndex((o) => o.id === c.id),
			explain: `${c.word} (${c.kana}, ${c.romaji}): ${c.meaning_vi}.`
		};
	});
}
var KINDS = [
	{
		id: "hira-romaji",
		label: "あ → a"
	},
	{
		id: "romaji-hira",
		label: "ka → か"
	},
	{
		id: "kata-romaji",
		label: "ア → a"
	},
	{
		id: "vocab-meaning",
		label: "Từ → nghĩa"
	},
	{
		id: "meaning-vocab",
		label: "Nghĩa → từ"
	},
	{
		id: "listen",
		label: "Nghe → chọn"
	},
	{
		id: "kanji",
		label: "Kanji"
	}
];
function srsOf(q) {
	const id = q.id.replace(/^q-(r-|l-|mv-|v-)?/, "");
	if (q.kind === "kanji") return {
		id,
		type: "kanji"
	};
	if (q.kind === "vocab-meaning" || q.kind === "meaning-vocab") return {
		id,
		type: "vocab"
	};
	return {
		id,
		type: "kana"
	};
}
function Page() {
	const [kind, setKind] = (0, import_react.useState)("hira-romaji");
	const [qs, setQs] = (0, import_react.useState)([]);
	const [i, setI] = (0, import_react.useState)(0);
	const [score, setScore] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [fill, setFill] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)(false);
	const log = useProgress((s) => s.logStudy);
	const mark = useProgress((s) => s.mark);
	const q = qs[i];
	(0, import_react.useEffect)(() => {
		setQs(makeQuiz(kind, 10));
		setI(0);
		setScore(0);
		setPicked(null);
		setDone(false);
	}, [kind]);
	async function finish(nextScore) {
		setDone(true);
		await addQuizResult({
			id: uid("quiz"),
			at: Date.now(),
			kind,
			score: nextScore,
			total: qs.length,
			durationMs: 0
		});
		await log(qs.length, 3);
	}
	function choose(idx) {
		if (!q || picked !== null) return;
		const ok = idx === q.answer;
		setPicked(idx);
		const next = score + (ok ? 1 : 0);
		setScore(next);
		const srs = srsOf(q);
		mark(srs.id, srs.type, ok ? "good" : "forgot");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "試験",
			title: "Quiz",
			description: "Nhiều dạng câu: chữ, từ, kanji, nghe. Điểm lưu trên máy."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: kind === k.id ? "default" : "secondary",
				onClick: () => setKind(k.id),
				children: k.label
			}, k.id))
		}),
		done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "mx-auto max-w-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "py-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Kết quả"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-4xl font-semibold tabular-nums",
						children: [
							score,
							"/",
							qs.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => {
							setQs(makeQuiz(kind, 10));
							setDone(false);
							setI(0);
							setScore(0);
							setPicked(null);
						},
						children: "Làm lại"
					})
				]
			})
		}) : q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "mx-auto max-w-lg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted tabular-nums",
						children: [
							"Câu ",
							i + 1,
							"/",
							qs.length,
							" · đúng ",
							score
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-jp text-4xl",
						children: q.promptJp ?? q.prompt
					}),
					q.promptJp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: q.prompt
					}) : null,
					q.speak ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeakButton, { text: q.speak }) : null,
					kind === "hira-romaji" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							const idx = q.options.findIndex((o) => normalizeRomaji(o) === normalizeRomaji(fill));
							choose(idx >= 0 ? idx : -1);
							setFill("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: fill,
							onChange: (e) => setFill(e.target.value),
							placeholder: "Điền romaji"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "OK"
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: q.options.map((o, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: picked === null ? "secondary" : idx === q.answer ? "success" : picked === idx ? "danger" : "secondary",
							className: "h-auto justify-start py-3 font-jp",
							onClick: () => choose(idx),
							children: [
								String.fromCharCode(65 + idx),
								". ",
								o
							]
						}, o + idx))
					}),
					picked !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: q.explain
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						onClick: () => {
							if (i + 1 >= qs.length) finish(score);
							else {
								setI((x) => x + 1);
								setPicked(null);
							}
						},
						children: i + 1 >= qs.length ? "Xem điểm" : "Câu tiếp"
					})] }) : null
				]
			})
		}) : null
	] });
}
//#endregion
export { Page as component };
