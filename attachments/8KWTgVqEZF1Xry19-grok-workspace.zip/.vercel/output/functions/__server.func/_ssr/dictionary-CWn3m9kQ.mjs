import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-_83nvF2z.mjs";
import { E as require_jsx_runtime, T as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-c9IIymTs.mjs";
import { n as useSettings } from "./settings-CfMxctWi.mjs";
import { _ as pushSearch, d as clearSearchHistory, x as searchHistory } from "./storage-BOiNWlU7.mjs";
import { t as PageHeader } from "./page-header-BwwPPGfl.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Search } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D2VeMEL1.mjs";
import { c as searchDictionary, i as fullDictionary, n as builtinDictionary, t as POS_FILTERS } from "./catalog-Dl3G3Fgy.mjs";
import { l as Route$24 } from "./router-YoCxU7dM.mjs";
import { t as Badge } from "./badge-COPtWlVw.mjs";
import { t as EmptyState } from "./empty-state-A1bLnuh-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dictionary-CWn3m9kQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { q: qParam = "" } = Route$24.useSearch();
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)(qParam);
	const [jlpt, setJlpt] = (0, import_react.useState)("all");
	const [pos, setPos] = (0, import_react.useState)("all");
	const [dict, setDict] = (0, import_react.useState)(() => builtinDictionary());
	const [recent, setRecent] = (0, import_react.useState)([]);
	const showRomaji = useSettings((s) => s.showRomaji);
	(0, import_react.useEffect)(() => {
		setQ(qParam);
	}, [qParam]);
	(0, import_react.useEffect)(() => {
		fullDictionary().then(setDict);
		searchHistory().then((h) => setRecent(h.map((x) => x.query)));
	}, []);
	const results = (0, import_react.useMemo)(() => {
		const query = q.trim();
		if (!query) return [];
		return searchDictionary(dict, {
			q: query,
			jlpt: jlpt === "all" ? void 0 : [jlpt],
			pos: pos === "all" ? void 0 : [pos],
			limit: 40
		});
	}, [
		dict,
		q,
		jlpt,
		pos
	]);
	const popular = (0, import_react.useMemo)(() => dict.filter((e) => e.common && e.frequency <= 2).slice(0, 12), [dict]);
	function commit(next) {
		const value = next.trim();
		setQ(next);
		navigate({
			to: "/dictionary",
			search: value ? { q: value } : {}
		});
		if (value) pushSearch(value).then(() => searchHistory().then((h) => setRecent(h.map((x) => x.query))));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "辞書",
			title: "Từ điển Nhật – Việt",
			description: "Tra kanji, kana, romaji hoặc tiếng Việt. Dữ liệu nằm trên máy — hoạt động khi tắt mạng."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "relative mb-4",
			onSubmit: (e) => {
				e.preventDefault();
				commit(q);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				onBlur: () => {
					if (q.trim() !== qParam) commit(q);
				},
				placeholder: "学校 · がっこう · gakkou · trường học",
				className: "h-12 pl-10",
				"aria-label": "Tra từ điển",
				autoFocus: true
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [
				[
					"all",
					"N5",
					"N4"
				].map((lv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: jlpt === lv ? "default" : "secondary",
					onClick: () => setJlpt(lv),
					children: lv === "all" ? "Mọi cấp" : lv
				}, lv)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 w-px self-stretch bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: pos === "all" ? "default" : "secondary",
					onClick: () => setPos("all"),
					children: "Mọi loại"
				}),
				POS_FILTERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: pos === p ? "default" : "secondary",
					onClick: () => setPos(p),
					children: p
				}, p))
			]
		}),
		q.trim() ? results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Không tìm thấy",
			description: "Thử romaji ngắn hơn (gakko), kana, hoặc thêm từ bằng công cụ import.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/tools/import-dictionary",
					children: "Import từ điển"
				})
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-2 text-sm text-muted",
			children: [
				results.length,
				" kết quả · ",
				dict.length,
				" mục trong máy"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-border rounded-xl border border-border bg-surface",
			children: results.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/dictionary/$id",
				params: { id: e.id },
				className: cn("flex items-center gap-3 px-4 py-3 hover:bg-bg-elevated"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-28 shrink-0 font-jp text-lg",
						children: e.kanji
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden w-28 shrink-0 text-sm text-accent sm:block",
						children: showRomaji ? e.romaji : e.kana
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1 truncate text-sm",
						children: e.meanings[0]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "muted",
						children: e.jlpt[0]
					})
				]
			}) }, e.id))
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [recent.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm text-muted",
					children: "Vừa tra"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-xs text-subtle underline",
					onClick: () => {
						clearSearchHistory();
						setRecent([]);
					},
					children: "Xóa"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: recent.slice(0, 10).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: () => commit(r),
					children: r
				}, r))
			})] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-sm text-muted",
				children: "Từ phổ biến"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2 sm:grid-cols-2",
				children: popular.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/dictionary/$id",
					params: { id: e.id },
					className: "flex items-center justify-between rounded-[10px] border border-border bg-surface px-4 py-3 hover:bg-bg-elevated",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-jp text-lg",
						children: e.kanji
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-sm text-muted",
						children: e.meanings[0]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "muted",
						children: e.jlpt[0]
					})]
				}) }, e.id))
			})] })]
		})
	] });
}
//#endregion
export { Page as component };
