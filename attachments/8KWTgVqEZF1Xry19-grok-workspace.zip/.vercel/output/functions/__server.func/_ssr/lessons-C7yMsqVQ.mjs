//#region node_modules/.nitro/vite/services/ssr/assets/lessons-C7yMsqVQ.js
var LESSONS = [
	{
		id: "l0-1",
		title: "Tiếng Nhật là gì?",
		title_jp: "日本語とは",
		stage: "nền tảng",
		level: "0",
		order: 1,
		summary: "Bốn lớp chữ viết và cách chúng sống chung trong một câu tiếng Nhật.",
		sections: [
			{
				heading: "Một ngôn ngữ, bốn cách ghi",
				body: "Tiếng Nhật hiện đại dùng hiragana, katakana, kanji và romaji cùng lúc. Hiragana ghi ngữ pháp và từ thuần Nhật. Katakana dành cho từ mượn, tên nước ngoài, âm thanh. Kanji mang nghĩa gốc Hán. Romaji là chữ Latin, hữu ích khi mới bắt đầu nhưng không thay được chữ Nhật khi đọc biển hiệu hay sách.",
				jp: "私は日本語を勉強します。",
				romaji: "Watashi wa nihongo o benkyou shimasu."
			},
			{
				heading: "Vì sao không chỉ học romaji?",
				body: "Romaji giúp phát âm lúc đầu, nhưng nhiều từ khác nhau trông giống nhau khi viết Latin. は có lúc đọc wa. こうこう có thể là 高校 hoặc 航行. Học hiragana sớm sẽ giúp bạn nhìn thấy ngữ pháp thật sự, không phụ thuộc phiên âm."
			},
			{
				heading: "Mục tiêu bài này",
				body: "Bạn chưa cần nhớ hết bảng chữ. Chỉ cần biết mỗi hệ chữ làm việc gì, và chấp nhận rằng một câu tiếng Nhật bình thường là hỗn hợp kanji + kana. Từ bài sau, chúng ta học cách đọc từng âm."
			}
		],
		practiceIds: ["h-a-あ", "v-n5-024"],
		unlocks: ["l0-2"]
	},
	{
		id: "l0-2",
		title: "Cách đọc tiếng Nhật",
		title_jp: "読み方",
		stage: "nền tảng",
		level: "0",
		order: 2,
		summary: "Mỗi mora (nhịp) gần như đều dài bằng nhau; phụ âm cuối gần như chỉ có ん.",
		sections: [
			{
				heading: "Đọc theo nhịp, không theo chữ cái Latin",
				body: "Tiếng Nhật chia nhịp theo mora. か là một nhịp. きゃ cũng là một nhịp. っ (âm ngắt) và ー (kéo dài) mỗi cái chiếm một nhịp. Vì vậy がっこう có bốn nhịp: ga-k-ko-u, không phải hai âm 'gak-kou' như nhiều người Việt tưởng.",
				jp: "がっこう",
				romaji: "gakkou"
			},
			{
				heading: "Cao độ quan trọng hơn trọng âm mạnh",
				body: "Tiếng Nhật không nhấn mạnh một âm tiết như tiếng Anh. Thay vào đó, cao độ (pitch) lên xuống. Ở giai đoạn đầu, phát âm đều và rõ vẫn tốt hơn cố bắt chước giọng Tokyo quá sớm. Nghe và nhắc lại sẽ tự chỉnh pitch."
			},
			{
				heading: "Ba âm hay nhầm",
				body: "し đọc shi, ふ đọc fu (gần như thổi hơi), つ đọc tsu. ん đứng trước nguyên âm đôi khi viết n' trong romaji để khỏi dính: てんいん → ten'in. Đừng nuốt ん thành m trừ khi môi đang chuẩn bị âm p/b/m."
			}
		],
		unlocks: ["l0-3"]
	},
	{
		id: "l0-3",
		title: "Nguyên âm",
		title_jp: "あいうえお",
		stage: "nền tảng",
		level: "0",
		order: 3,
		summary: "Năm nguyên âm あいうえお là xương sống của toàn bộ bảng năm mươi âm.",
		sections: [
			{
				heading: "Năm âm, miệng không đổi giữa chừng",
				body: "あ a miệng mở. い i môi dẹt, lưỡi cao. う u môi tròn nhẹ, không bật mạnh như 'u' tiếng Việt miền Bắc. え e nửa mở. お o tròn, ngắn. Giữ nguyên hình miệng đến hết âm; đừng biến え thành 'ê' kéo dài.",
				jp: "あいうえお",
				romaji: "a i u e o"
			},
			{
				heading: "Nguyên âm dài",
				body: "おう thường romanize thành ou (東京 toukyou). ええ thành ee. いい thành ii. Đọc thiếu độ dài có thể đổi nghĩa: おばさん (dì) khác おばあさん (bà). Hãy đếm nhịp khi luyện."
			},
			{
				heading: "Luyện trước khi vào hàng phụ âm",
				body: "Đọc xuôi あいうえお rồi ngược おえういあ. Khi ổn định, hàng かさたな sẽ chỉ là thêm phụ âm vào năm khuôn miệng này."
			}
		],
		practiceIds: [
			"h-a-あ",
			"h-i-い",
			"h-u-う",
			"h-e-え",
			"h-o-お"
		],
		unlocks: ["l-n5-hira-a"]
	},
	{
		id: "l-n5-hira-a",
		title: "Hiragana hàng nguyên âm",
		title_jp: "あ行",
		stage: "hiragana",
		level: "N5",
		order: 4,
		summary: "あいうえお: nét viết, chiều bút và từ minh họa ngắn.",
		sections: [{
			heading: "Nhìn hình, nhớ nét",
			body: "あ giống người cúi chào, viết ba nét. い hai nét song song. う hai nét, nét hai cong như cái bát. え hai nét, nét dưới quét sang phải. お ba nét, đừng quên chấm nhỏ. Viết theo đúng thứ tự nét sẽ dễ nhớ hơn vẽ theo cảm tính.",
			jp: "あさ いぬ うみ えき お茶",
			romaji: "asa inu umi eki ocha"
		}, {
			heading: "Ghép thành từ thật",
			body: "あさ buổi sáng, いぬ con chó, うみ biển, えき nhà ga, お ở đầu nhiều từ lịch sự như お茶. Đọc to từng mora, đừng dồn thành một tiếng Việt."
		}],
		practiceIds: ["h-a-あ"],
		unlocks: ["l-n5-hira-ka"]
	},
	{
		id: "l-n5-hira-ka",
		title: "Hiragana hàng KA",
		title_jp: "か行",
		stage: "hiragana",
		level: "N5",
		order: 5,
		summary: "かきくけこ và cặp dakuten がぎぐげご.",
		sections: [{
			heading: "Hàng KA",
			body: "か ki く ke こ. き có thể viết nét dưới rời hoặc liền; cả hai đều chấp nhận. く một nét chéo. こ hai nét ngang. Đây là hàng rất hay gặp: かさ ô, き cây, くに đất nước.",
			jp: "かきくけこ",
			romaji: "ka ki ku ke ko"
		}, {
			heading: "Dakuten biến thành GA",
			body: "Hai chấm dakuten biến か thành が. がっこう trường học, ごはん cơm. Đọc g mềm, không phải 'gờ' nặng. Luyện か/が cạnh nhau để tai phân biệt."
		}],
		unlocks: ["l-n5-hira-sa"]
	},
	{
		id: "l-n5-hira-sa",
		title: "Hiragana hàng SA",
		title_jp: "さ行",
		stage: "hiragana",
		level: "N5",
		order: 6,
		summary: "さしすせそ — nhớ し đọc shi, không phải si.",
		sections: [{
			heading: "し là âm đặc biệt",
			body: "Hàng này không đều: さ su se so đi với s, nhưng し đọc shi. すし sushi, せんせい sensei, そら bầu trời. Viết し một nét mềm từ trên xuống.",
			jp: "さくら しお すし せかい そら",
			romaji: "sakura shio sushi sekai sora"
		}, {
			heading: "ZA hàng dakuten",
			body: "ざじずぜぞ. じ đọc ji. じしょ từ điển, かぜ gió (không thuộc hàng này nhưng hay nhầm せ/ぜ). Đọc chậm để khỏi trượt thành tiếng Việt 'gi'."
		}],
		unlocks: ["l-n5-hira-ta"]
	},
	{
		id: "l-n5-hira-ta",
		title: "Hiragana hàng TA",
		title_jp: "た行",
		stage: "hiragana",
		level: "N5",
		order: 7,
		summary: "たちつてと — ち chi, つ tsu, っ âm ngắt.",
		sections: [{
			heading: "chi và tsu",
			body: "た te to bình thường, nhưng ち đọc chi, つ đọc tsu. つき mặt trăng, ちず bản đồ, たべる ăn. Đừng đọc 'ti' hay 'tu'.",
			jp: "たべる ちず つき て とり",
			romaji: "taberu chizu tsuki te tori"
		}, {
			heading: "っ nhỏ",
			body: "っ không có âm riêng; nó ngắt rồi nhân phụ âm sau: がっこう gakkou, きって kitte. Đếm một nhịp im. Thiếu っ là sai từ."
		}],
		unlocks: ["l-n5-hira-na"]
	},
	{
		id: "l-n5-hira-na",
		title: "Hiragana hàng NA",
		title_jp: "な行",
		stage: "hiragana",
		level: "N5",
		order: 8,
		summary: "なにぬねの và trợ từ の.",
		sections: [{
			heading: "Năm chữ NA",
			body: "な nét nhiều, viết chậm. に ba nét. の một vòng — vừa là âm no vừa là trợ từ 'của'. ねこ mèo, なつ mùa hè, にほん Nhật Bản.",
			jp: "なつ にほん ぬの ねこ のり",
			romaji: "natsu nihon nuno neko nori"
		}, {
			heading: "ん đứng riêng",
			body: "ん không thuộc hàng NA nhưng hay đi sau các âm này: にほん, さん. ん không bao giờ đứng đầu từ. Trước nguyên âm, hãy tách nhịp: てんいん là ten-in, bốn mora."
		}],
		unlocks: ["l-n5-hira-ha"]
	},
	{
		id: "l-n5-hira-ha",
		title: "Hiragana hàng HA",
		title_jp: "は行",
		stage: "hiragana",
		level: "N5",
		order: 9,
		summary: "はひふへほ; trợ từ は đọc wa, へ đọc e.",
		sections: [{
			heading: "ふ là fu",
			body: "は hi ふ he ほ. ふ thổi hơi qua răng, không phải 'phu' nặng. ふゆ mùa đông, ひと người, ほん sách.",
			jp: "はな ひと ふゆ へや ほし",
			romaji: "hana hito fuyu heya hoshi"
		}, {
			heading: "Hai trợ từ đọc khác chữ",
			body: "Khi は là chủ đề, đọc wa: 私は watashi wa. Khi へ chỉ hướng, đọc e: 学校へ gakkou e. Dakuten ばびぶべぼ, handakuten ぱぴぷぺぽ. ぱ có thêm vòng tròn nhỏ."
		}],
		unlocks: ["l-n5-hira-ma"]
	},
	{
		id: "l-n5-hira-ma",
		title: "Hiragana hàng MA",
		title_jp: "ま行",
		stage: "hiragana",
		level: "N5",
		order: 10,
		summary: "まみむめも — hàng tròn môi.",
		sections: [{
			heading: "Năm chữ MA",
			body: "ま mi mu me mo. まど cửa sổ, みず nước, むし côn trùng, め mắt, もも đào. も cũng là trợ từ 'cũng'.",
			jp: "まど みず むし め もも",
			romaji: "mado mizu mushi me momo"
		}, {
			heading: "Nhầm nét với hàng NA",
			body: "ま và ほ, ぬ và め dễ lẫn khi viết nhanh. So sánh từng chữ: め có vòng khép, ぬ có vòng + móc. Viết chậm mười lần hơn viết nhanh sai một trang."
		}],
		unlocks: ["l-n5-hira-ya"]
	},
	{
		id: "l-n5-hira-ya",
		title: "Hiragana hàng YA, RA, WA",
		title_jp: "や行・ら行・わ行",
		stage: "hiragana",
		level: "N5",
		order: 11,
		summary: "やゆよ, らりるれろ, わをん và âm ghép yoon.",
		sections: [{
			heading: "Ba hàng còn lại",
			body: "やゆよ không có yi, ye. らりるれろ lưỡi chạm nướu rất nhẹ, không phải 'r' rung cũng không phải 'l' đậm. わをん: を chỉ dùng làm trợ từ tân ngữ, đọc o. ん là mora mũi.",
			jp: "やま ゆき よる さくら わたし",
			romaji: "yama yuki yoru sakura watashi"
		}, {
			heading: "Yoon: きゃ, しゅ, ちょ",
			body: "Ghép き+ゃ nhỏ thành kya, một nhịp. しゃ sha, しゅ shu, しょ sho. 小さい là chiisai, có っ và い dài. Đọc きや (hai nhịp) khác きゃ (một nhịp)."
		}],
		unlocks: ["l-n5-hira"]
	},
	{
		id: "l-n5-hira",
		title: "Hiragana tổng hợp",
		title_jp: "ひらがな",
		stage: "hiragana",
		level: "N5",
		order: 12,
		summary: "Ôn gojuon, dakuten, handakuten, yoon, sokuon và cách dùng hiragana trong câu.",
		sections: [{
			heading: "Hiragana làm gì trong câu",
			body: "Hiragana ghi trợ từ (はがをにでへ), đuôi động từ (ます, ない, て) và từ thuần Nhật chưa viết kanji. Một người lớn Nhật vẫn viết rất nhiều hiragana mỗi ngày; đây không phải 'chữ trẻ con' để bỏ sau khi biết kanji."
		}, {
			heading: "Luyện đọc hỗn hợp",
			body: "Đọc câu có cả dakuten và っ: がっこうでべんきょうします. Đếm mora. Khi vấp, khoanh chữ rồi viết lại hàng đó, đừng đọc lướt romaji.",
			jp: "がっこうでべんきょうします。",
			romaji: "Gakkou de benkyou shimasu."
		}],
		practiceIds: ["l-n5-hira-a", "l-n5-hira-ka"],
		unlocks: ["l-n5-kata"]
	},
	{
		id: "l-n5-kata",
		title: "Katakana",
		title_jp: "カタカナ",
		stage: "katakana",
		level: "N5",
		order: 13,
		summary: "Bảng katakana, nét thẳng, từ mượn và dấu kéo dài ー.",
		sections: [
			{
				heading: "Cùng âm, khác nét",
				body: "Katakana ghi đúng bộ âm hiragana nhưng nét góc cạnh hơn. アカサタナ... Dùng cho từ mượn (コーヒー, バス, パン), tên nước ngoài, và khi muốn nhấn mạnh.",
				jp: "コーヒー バス パン トイレ",
				romaji: "koohii basu pan toire"
			},
			{
				heading: "Dấu ー",
				body: "Trong katakana, nguyên âm dài thường viết ー: スーパー suupaa, コーヒー koohii. Đọc đủ nhịp. コンピュータとコンピューター khác độ dài tùy từ; dạng dài phổ biến hơn trong đời sống."
			},
			{
				heading: "Âm nước ngoài",
				body: "Tiếng Nhật thêm ファ, ティ, ヴァ cho âm lạ. Ở N5, thuộc lòng từ thường gặp quan trọng hơn thuộc hết tổ hợp hiếm. Gặp từ mới, đọc theo katakana trước, đoán nghĩa sau."
			}
		],
		unlocks: ["l-n5-vocab"]
	},
	{
		id: "l-n5-vocab",
		title: "Từ vựng N5",
		title_jp: "語彙 N5",
		stage: "từ vựng",
		level: "N5",
		order: 14,
		summary: "Nhóm từ đời sống: chào hỏi, trường lớp, thời gian, động từ cơ bản.",
		sections: [
			{
				heading: "Học theo cảnh, không theo danh sách khô",
				body: "Mỗi từ N5 nên gắn một câu bạn có thể nói hôm nay: 水をください, 学校へ行きます, これは本です. Từ đứng một mình dễ quên. Hãy học kèm category: chào hỏi, gia đình, đồ ăn, giao thông.",
				jp: "私は毎日日本語を勉強します。",
				romaji: "Watashi wa mainichi nihongo o benkyou shimasu."
			},
			{
				heading: "Động từ ba nhóm",
				body: "Nhóm 1 (五段) đổi âm: 行く→行きます. Nhóm 2 (一段) bỏ る: 食べる→食べます. Nhóm 3 chỉ する và 来る. Biết nhóm từ lúc học từ vựng sẽ đỡ khổ khi chia て và ない."
			},
			{
				heading: "Số và thời gian",
				body: "Một đến mười, trăm nghìn vạn, thứ trong tuần, 時 và 分 là xương sống nghe hiểu. 四 đọc yon hoặc yo, 七 nana hoặc shichi tùy collocation: よじ, しちがつ."
			}
		],
		practiceIds: [
			"v-n5-021",
			"v-n5-024",
			"v-n5-133"
		],
		unlocks: ["l-n5-grammar"]
	},
	{
		id: "l-n5-grammar",
		title: "Ngữ pháp N5",
		title_jp: "文法 N5",
		stage: "ngữ pháp",
		level: "N5",
		order: 15,
		summary: "Trợ từ はがをにでへ, thể ます, dạng て, tồn tại ある/いる.",
		sections: [
			{
				heading: "Câu lịch sự tối thiểu",
				body: "Chủ đề は, tân ngữ を, đích に/へ, nơi hành động で, rồi động từ thể ます. 私は図書館で本を読みます. Đổi đuôi ます/ません/ました là bạn đã kể được hiện tại, phủ định và quá khứ.",
				jp: "私は図書館で本を読みます。",
				romaji: "Watashi wa toshokan de hon o yomimasu."
			},
			{
				heading: "は và が",
				body: "は giới thiệu đề tài. が chỉ chủ thể mới hoặc đối tượng của 好き/分かる/いる. Câu 'có một con mèo' dùng が: 猫がいます. Đừng dịch cứng 'ga là chủ ngữ, wa là topic' rồi sợ dùng sai — hãy nhìn mẫu câu."
			},
			{
				heading: "Dạng て mở cửa nhiều mẫu",
				body: "てください nhờ vả, ています đang/kết quả, てもいい xin phép. Thuộc bảng biến âm nhóm 1 trước khi nhảy mẫu khác. 行く là 行って, không theo quy tắc いて."
			}
		],
		practiceIds: [
			"g-n5-01",
			"g-n5-03",
			"g-n5-19"
		],
		unlocks: ["l-n5-kanji"]
	},
	{
		id: "l-n5-kanji",
		title: "Kanji N5",
		title_jp: "漢字 N5",
		stage: "kanji",
		level: "N5",
		order: 16,
		summary: "Khoảng 80 chữ: số, thời gian, người, trường, động từ đời sống.",
		sections: [
			{
				heading: "Mỗi chữ hai việc: nghĩa và cách đọc",
				body: "Kanji có âm on (gốc Hán, hay gặp trong từ ghép) và kun (đọc Nhật, hay gặp khi đứng một mình hoặc có okurigana). 山 vừa là サン trong 富士山 vừa là やま. Học kèm từ ghép, đừng học đọc trần.",
				jp: "山 川 日 月 人",
				romaji: "yama kawa nichi tsuki hito"
			},
			{
				heading: "Thứ tự nét",
				body: "Trên trước dưới, trái trước phải, ngang trước sổ khi nét cắt. 十 hai nét, 言 bảy nét. Viết đúng nét giúp nhớ chữ và tra từ điển giấy sau này."
			},
			{
				heading: "Cụm nên thuộc sớm",
				body: "日本, 学生, 先生, 今日, 明日, 食べる, 行く, 見る. Đây là chữ bạn sẽ gặp lại trong mọi bài đọc N5. Mỗi ngày 5 chữ kèm 2 từ ghép hiệu quả hơn 20 chữ không câu."
			}
		],
		practiceIds: [
			"kj-n5-日",
			"kj-n5-学",
			"kj-n5-食"
		],
		unlocks: ["l-n5-read"]
	},
	{
		id: "l-n5-read",
		title: "Đọc hiểu N5",
		title_jp: "読解 N5",
		stage: "đọc",
		level: "N5",
		order: 17,
		summary: "Đoạn 40–80 chữ: lịch sinh hoạt, mua sắm, thời tiết.",
		sections: [{
			heading: "Đọc theo cụm, không dịch từng chữ",
			body: "Tìm chủ đề は, chỗ có に/で, rồi động từ cuối. Tiếng Nhật đặt thông tin chính ở cuối câu. Nếu dịch từ trái sang phải như tiếng Việt, bạn sẽ lạc mất thì và phủ định."
		}, {
			heading: "Kanji lạ thì đoán từ kana quanh nó",
			body: "Bài N5 thường furigana hoặc dùng chữ đã học. Gặp chữ mới, nhìn okurigana: 〜べます gần như 食べます. Đừng dừng lại năm phút cho một chữ nếu câu vẫn hiểu."
		}],
		unlocks: ["l-n5-listen"]
	},
	{
		id: "l-n5-listen",
		title: "Nghe hiểu N5",
		title_jp: "聴解 N5",
		stage: "nghe",
		level: "N5",
		order: 18,
		summary: "Nghe câu ngắn: giờ giấc, giá tiền, chỗ gặp, đồng ý/từ chối.",
		sections: [{
			heading: "Nghe số và trợ từ trước",
			body: "Trong hội thoại N5, đáp án thường nằm ở số (三時, 五百円) hoặc trợ từ (で/に/へ). は đọc wa dễ nuốt — luyện câu これは…ですか đến khi tai bắt được."
		}, {
			heading: "Đừng chờ hiểu 100%",
			body: "Nghe một lần để bắt chủ đề, lần hai để chọn đáp án. はい/いいえ, すみません, まだ, もう là tín hiệu cực mạnh. TTS trong app đọc promptJp; hãy nhại lại ngay sau khi nghe."
		}],
		unlocks: ["l-n5-quiz"]
	},
	{
		id: "l-n5-quiz",
		title: "Kiểm tra N5",
		title_jp: "確認テスト N5",
		stage: "kiểm tra",
		level: "N5",
		order: 19,
		summary: "Ôn hiragana, từ vựng, trợ từ, kanji số-thời gian trước khi sang N4.",
		sections: [{
			heading: "Checklist tự kiểm",
			body: "Đọc được bảng hiragana không nhìn romaji. Viết được 20 kanji số và hướng. Tạo câu với はをにで. Kể một ngày của bạn bằng ます/ました. Nếu vấp hàng た/は, quay lại bài hàng chữ trước khi làm đề."
		}, {
			heading: "Lỗi hay gặp",
			body: "Nhầm は/が, quên です ở câu danh từ, đọc を thành wo, viết 行いて thay vì 行って. Ghi lỗi vào thẻ, ôn bằng SRS thay vì đọc lại cả giáo trình."
		}],
		unlocks: ["l-n4-vocab"]
	},
	{
		id: "l-n4-vocab",
		title: "Từ vựng N4",
		title_jp: "語彙 N4",
		stage: "từ vựng",
		level: "N4",
		order: 20,
		summary: "Động từ trừu tượng hơn: 考える, 決める, 続ける; danh từ công việc và xã hội.",
		sections: [{
			heading: "Từ N4 sống trong cụm",
			body: "経験を積む, 連絡する, 予約を取る. Học động từ cùng tân ngữ và trợ từ. 間に合う đi với に, 比べる đi với と hoặc を. Một mình 経験 không giúp bạn nói được câu.",
			jp: "会議の前に資料を準備します。",
			romaji: "Kaigi no mae ni shiryou o junbi shimasu."
		}, {
			heading: "Trạng từ làm câu tự nhiên",
			body: "必ず, 特に, やっと, なかなか, はっきり. Chúng không đổi nghĩa gốc nhưng đổi thái độ. なかなかできません thú nhận khó, khác できません trần."
		}],
		practiceIds: ["v-n4-001", "v-n4-020"],
		unlocks: ["l-n4-kanji"]
	},
	{
		id: "l-n4-kanji",
		title: "Kanji N4",
		title_jp: "漢字 N4",
		stage: "kanji",
		level: "N4",
		order: 21,
		summary: "Chữ công việc, trường lớp, thời gian tương đối: 会社発着, 始終, 思考.",
		sections: [{
			heading: "Từ ghép hai chữ",
			body: "N4 tăng mạnh từ 熟語: 会議, 研究, 到着, 出発, 世界. Đọc on chiếm đa số. Khi hai chữ đứng cạnh, thử đọc on trước, kun sau.",
			jp: "会社で会議があります。",
			romaji: "Kaisha de kaigi ga arimasu."
		}, {
			heading: "Chữ dễ lẫn",
			body: "待 và 持, 始 và 終, 速 và 遅. So sánh bộ thủ: 待 có bộ bước 彳, 持 có bộ tay 扌. Viết cạnh nhau một dòng sẽ nhớ lâu hơn học rời."
		}],
		practiceIds: ["kj-n4-会", "kj-n4-仕"],
		unlocks: ["l-n4-grammar"]
	},
	{
		id: "l-n4-grammar",
		title: "Ngữ pháp N4",
		title_jp: "文法 N4",
		stage: "ngữ pháp",
		level: "N4",
		order: 22,
		summary: "Suy đoán ようだ/らしい/そうだ, điều kiện ば/たら/なら, ために/ように, nghĩa vụ.",
		sections: [
			{
				heading: "Nối câu thay vì câu đơn",
				body: "N4 đòi bạn giải thích lý do (ので), trái ngược (のに), mục đích (ために/ように) và điều kiện. Hãy giữ thể ngắn trước các mẫu này, trừ khi cố ý dùng ますので cho lịch sự."
			},
			{
				heading: "Ba điều kiện không trùng nhau",
				body: "ば giả định tổng quát, たら rộng và tự nhiên, なら lấy lời người kia làm giả thiết. Lời khuyên hay dùng たらどう. Đừng chọn mẫu vì 'trông khó hơn'.",
				jp: "時間があれば、一緒に行きましょう。",
				romaji: "Jikan ga areba, issho ni ikimashou."
			},
			{
				heading: "Mẫu て dày hơn",
				body: "てしまう hoàn tất hoặc nuối tiếc, ておく chuẩn bị, てみる thử. Học chúng như thái độ, không chỉ như công thức."
			}
		],
		practiceIds: [
			"g-n4-01",
			"g-n4-10",
			"g-n4-16"
		],
		unlocks: ["l-n4-read"]
	},
	{
		id: "l-n4-read",
		title: "Đọc hiểu N4",
		title_jp: "読解 N4",
		stage: "đọc",
		level: "N4",
		order: 23,
		summary: "Thư ngắn, thông báo, nhật ký: tìm lý do và quan hệ nhân quả.",
		sections: [{
			heading: "Hỏi bài đọc đang làm gì",
			body: "Thư xin nghỉ, thông báo đổi giờ, đoạn kể bị lỡ tàu. Khoanh ので/のに/ために. Câu hỏi N4 hay hỏi 'vì sao' hoặc 'sắp làm gì', ít hỏi nghĩa từng từ."
		}, {
			heading: "Quan hệ đại từ",
			body: "それ, この, そんな thường trỏ ý vừa nêu, không phải vật trên bàn. Đọc lại câu trước khi chọn 'cái này là gì'."
		}],
		unlocks: ["l-n4-listen"]
	},
	{
		id: "l-n4-listen",
		title: "Nghe hiểu N4",
		title_jp: "聴解 N4",
		stage: "nghe",
		level: "N4",
		order: 24,
		summary: "Hội thoại hai lượt: đổi kế hoạch, xin phép, truyền đạt tin.",
		sections: [{
			heading: "Nghe câu cuối",
			body: "Người Nhật thường nêu tình huống rồi mới chốt ý định. Đáp án hay nằm ở 〜つもり, 〜なければならない, 〜たらどう. Đừng chọn lựa chọn xuất hiện đầu tiên rồi bỏ nghe."
		}, {
			heading: "Tin đồn và suy đoán",
			body: "そうです (nghe nói), ようです, らしいです nghe giống nhau nếu bạn chỉ bắt そう. Chú ý phần trước: thể ngắn + そうだ là truyền tin; 美味しそう là vẻ bề ngoài."
		}],
		unlocks: ["l-n4-quiz"]
	},
	{
		id: "l-n4-quiz",
		title: "Kiểm tra N4",
		title_jp: "確認テスト N4",
		stage: "kiểm tra",
		level: "N4",
		order: 25,
		summary: "Đo độ chắc của điều kiện, mẫu て, từ vựng công việc và kanji ghép.",
		sections: [{
			heading: "Tự ra đề cho mình",
			body: "Viết năm câu: một たら, một ので, một ておく, một なければならない, một そうだ truyền tin. Đọc lại ngày hôm sau. Nếu không sửa được lỗi của chính mình, điểm từ vựng chưa đủ — quay lại thẻ SRS."
		}, {
			heading: "Sau N4",
			body: "N3 sẽ thêm thể bị động, sai khiến, 敬語. Nền N4 vững là câu phức có lý do-mục đích-điều kiện trôi chảy, không phải thuộc thêm 200 chữ rồi quên trợ từ."
		}]
	}
];
//#endregion
export { LESSONS as t };
