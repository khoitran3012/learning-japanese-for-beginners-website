import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-_83nvF2z.mjs";
import { E as require_jsx_runtime, T as require_react, a as Overlay2, c as Title2, i as Description2, l as Trigger2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as buttonVariants, t as Button } from "./button-c9IIymTs.mjs";
import { n as useSettings } from "./settings-CfMxctWi.mjs";
import { T as wipeUserData, g as importAll, m as exportAll, w as validateBackup } from "./storage-BOiNWlU7.mjs";
import { i as useProgress } from "./progress-DkeQVu5t.mjs";
import { n as KATAKANA, t as HIRAGANA } from "./kana-CV-aAiLY.mjs";
import { n as KANJI_N5, t as KANJI_N4 } from "./kanji-n4-Bq9tkueZ.mjs";
import { t as LESSONS } from "./lessons-C7yMsqVQ.mjs";
import { n as VOCAB_N5, t as VOCAB_N4 } from "./vocabulary-n4-Bzb_ewCa.mjs";
import { t as PageHeader } from "./page-header-BwwPPGfl.mjs";
import { n as CardContent, t as Card } from "./card-7M-NYlJ1.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as GRAMMAR_N5, t as GRAMMAR_N4 } from "./grammar-n4-Dv0a1spF.mjs";
import { n as searchLocal, t as buildDictionary } from "./local-CAR8tw6H.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Label } from "./label-vEIclOZ2.mjs";
import { t as Switch } from "./switch-D_Yjx8EG.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-B4_dO7JX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DataProvider = class {};
var current = null;
function setDataProvider(provider) {
	current = provider;
}
function getDataProvider() {
	if (!current) throw new Error("DataProvider chưa được khởi tạo");
	return current;
}
var LocalDataProvider = class extends DataProvider {
	name = "local";
	dict = null;
	async getKana() {
		return [...HIRAGANA, ...KATAKANA];
	}
	async getVocab() {
		return [...VOCAB_N5, ...VOCAB_N4];
	}
	async getKanji() {
		return [...KANJI_N5, ...KANJI_N4];
	}
	async getGrammar() {
		return [...GRAMMAR_N5, ...GRAMMAR_N4];
	}
	async getLessons() {
		return LESSONS;
	}
	async getDictionary() {
		if (!this.dict) {
			const extra = await import("./dictionary-extra-Ca9ZP6BQ.mjs").then((n) => n.n).then((n) => n.n).then((m) => m.DICTIONARY_EXTRA);
			this.dict = buildDictionary([...VOCAB_N5, ...VOCAB_N4], [...KANJI_N5, ...KANJI_N4], extra);
		}
		return this.dict;
	}
	async searchDictionary(query) {
		const dict = await this.getDictionary();
		return searchLocal(dict, query);
	}
};
var RemoteDataProvider = class extends DataProvider {
	fallback;
	name = "remote";
	constructor(fallback) {
		super();
		this.fallback = fallback;
	}
	getKana() {
		return this.fallback.getKana();
	}
	getVocab() {
		return this.fallback.getVocab();
	}
	getKanji() {
		return this.fallback.getKanji();
	}
	getGrammar() {
		return this.fallback.getGrammar();
	}
	getLessons() {
		return this.fallback.getLessons();
	}
	getDictionary() {
		return this.fallback.getDictionary();
	}
	async searchDictionary(query) {
		try {
			const local = await this.fallback.searchDictionary(query);
			if (local.length > 0) return local;
			return local;
		} catch {
			return this.fallback.searchDictionary(query);
		}
	}
};
var local = new LocalDataProvider();
var remote = new RemoteDataProvider(local);
setDataProvider(local);
function useLocalFirst(online = false) {
	setDataProvider(online ? remote : local);
	return getDataProvider();
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full border border-border bg-surface shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
	});
}
var AlertDialog = Root2;
var AlertDialogTrigger = Trigger2;
function AlertDialogContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Portal2, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		className: cn("fixed left-1/2 top-1/2 z-50 w-[min(440px,calc(100vw-1.5rem))] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-surface p-5 text-fg shadow-[var(--shadow-soft)]", className),
		...props
	})] });
}
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("space-y-2", className),
		...props
	});
}
function AlertDialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
		className: cn("text-lg font-semibold", className),
		...props
	});
}
function AlertDialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
		className: cn("text-sm text-muted", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-5 flex justify-end gap-2", className),
		...props
	});
}
function AlertDialogCancel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
		className: cn(buttonVariants({ variant: "secondary" }), className),
		...props
	});
}
function AlertDialogAction({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
		className: cn(buttonVariants({ variant: "danger" }), className),
		...props
	});
}
function Page() {
	const settings = useSettings();
	const load = useProgress((s) => s.load);
	const fileRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		useLocalFirst(settings.onlineDictionary);
	}, [settings.onlineDictionary]);
	async function onExport() {
		const payload = await exportAll({
			theme: settings.theme,
			fontSize: settings.fontSize,
			showRomaji: settings.showRomaji,
			autoPlayAudio: settings.autoPlayAudio,
			ttsRate: settings.ttsRate,
			dailyGoal: settings.dailyGoal,
			flashcardPerDay: settings.flashcardPerDay,
			freeMode: settings.freeMode,
			onlineDictionary: settings.onlineDictionary,
			reducedMotion: settings.reducedMotion
		});
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `akari-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
		a.click();
		URL.revokeObjectURL(url);
		toast("Đã tải file sao lưu");
	}
	async function onImport(file) {
		setBusy(true);
		try {
			const text = await file.text();
			const data = JSON.parse(text);
			if (!validateBackup(data)) {
				toast.error("File sao lưu không hợp lệ");
				return;
			}
			await importAll(data);
			if (data.settings && typeof data.settings === "object") settings.set(data.settings);
			await load();
			toast("Đã khôi phục dữ liệu");
		} catch {
			toast.error("Không đọc được file");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "設定",
		title: "Cài đặt",
		description: "Giao diện, ôn tập và sao lưu — tất cả lưu trên máy này."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: "Giao diện"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							["system", "Theo hệ thống"],
							["light", "Sáng"],
							["dark", "Tối"]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: settings.theme === id ? "default" : "secondary",
							onClick: () => settings.set({ theme: id }),
							children: label
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "mb-2 block",
						children: "Cỡ chữ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: [
							"sm",
							"md",
							"lg"
						].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: settings.fontSize === id ? "default" : "secondary",
							onClick: () => settings.set({ fontSize: id }),
							children: id === "sm" ? "Nhỏ" : id === "md" ? "Vừa" : "Lớn"
						}, id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "romaji",
							children: "Hiện Romaji"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: "romaji",
							checked: settings.showRomaji,
							onCheckedChange: (v) => settings.set({ showRomaji: v })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "motion",
							children: "Giảm chuyển động"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: "motion",
							checked: settings.reducedMotion,
							onCheckedChange: (v) => settings.set({ reducedMotion: v })
						})]
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: "Học tập"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
						className: "mb-2 block",
						children: [
							"Mục tiêu mỗi ngày: ",
							settings.dailyGoal,
							" phút"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 5,
						max: 60,
						step: 5,
						value: [settings.dailyGoal],
						onValueChange: ([v]) => settings.set({ dailyGoal: v ?? 15 })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
						className: "mb-2 block",
						children: ["Flashcard mỗi phiên: ", settings.flashcardPerDay]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 5,
						max: 40,
						step: 5,
						value: [settings.flashcardPerDay],
						onValueChange: ([v]) => settings.set({ flashcardPerDay: v ?? 20 })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
						className: "mb-2 block",
						children: ["Tốc độ đọc: ", settings.ttsRate.toFixed(1)]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: .6,
						max: 1.2,
						step: .1,
						value: [settings.ttsRate],
						onValueChange: ([v]) => settings.set({ ttsRate: v ?? .9 })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "autoplay",
							children: "Tự đọc khi mở thẻ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: "autoplay",
							checked: settings.autoPlayAudio,
							onCheckedChange: (v) => settings.set({ autoPlayAudio: v })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "free",
							children: "Mở khóa lộ trình (chế độ tự do)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: "free",
							checked: settings.freeMode,
							onCheckedChange: (v) => settings.set({ freeMode: v })
						})]
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: "Từ điển"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Mặc định tra trong dữ liệu local. Bật nguồn bổ sung chỉ khi bạn tự cấu hình — nếu lỗi, app vẫn dùng từ điển máy."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "online",
							children: "Thử nguồn từ điển bổ sung (tùy chọn)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: "online",
							checked: settings.onlineDictionary,
							onCheckedChange: (v) => settings.set({ onlineDictionary: v })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/import-dictionary",
							children: "Import / kiểm tra từ điển"
						})
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: "Sao lưu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "File JSON chứa tiến độ SRS, yêu thích, từ của bạn và cài đặt. Không gửi lên máy chủ."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => void onExport(),
								children: "Tải sao lưu"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								disabled: busy,
								onClick: () => fileRef.current?.click(),
								children: "Khôi phục"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: "application/json",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) onImport(f);
									e.target.value = "";
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							children: "Xóa dữ liệu trên máy"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Xóa toàn bộ tiến độ?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "SRS, yêu thích, từ của bạn và lịch sử tra sẽ mất. Hãy sao lưu trước nếu cần." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Hủy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						onClick: async () => {
							await wipeUserData();
							localStorage.removeItem("akari-settings");
							toast("Đã xóa dữ liệu");
							window.location.reload();
						},
						children: "Xóa"
					})] })] })] })
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-2 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium text-fg",
						children: "Akari"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Học tiếng Nhật từ số 0, ưu tiên N5 → N4. Dữ liệu bài học là nội dung gốc, không sao chép giáo trình thương mại." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Giấy phép mã nguồn MIT. Font và thư viện ghi trong ATTRIBUTIONS.md." })
				]
			}) })
		]
	})] });
}
//#endregion
export { Page as component };
