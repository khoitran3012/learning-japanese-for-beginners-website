import { i as __toESM } from "../_runtime.mjs";
import { E as require_jsx_runtime, T as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as createRootRoute, b as useRouter, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rolldown-runtime-D7D4PA-g.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-YoCxU7dM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-BOZAFbMB.css";
var APP_NAME = "Akari";
var THEME_BOOT = `(function(){try{var r=JSON.parse(localStorage.getItem('akari-settings')||'{}');var t=(r.state&&r.state.theme)||'system';var d=t==='dark'||(t==='system'&&window.matchMedia('(prefers-color-scheme: dark)').matches);document.documentElement.classList.toggle('dark',d);var f=(r.state&&r.state.fontSize)||'md';document.documentElement.classList.add('font-'+f);}catch(e){}})();`;
var Route$28 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Akari — học tiếng Nhật từ số 0, ưu tiên N5 đến N4, hoạt động trên máy của bạn."
			},
			{
				name: "theme-color",
				content: "#2f4158"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Noto+Sans+JP:wght@400;500;700&family=Noto+Serif+JP:wght@500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "vi",
		suppressHydrationWarning: true,
		className: "antialiased",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_BOOT } }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$27 = () => import("../_app-CHxEqIiA.mjs");
var Route$27 = createFileRoute("/_app")({ component: lazyRouteComponent($$splitComponentImporter$27, "component") });
var $$splitComponentImporter$26 = () => import("../_app-BT2Tl4bM.mjs");
var Route$26 = createFileRoute("/_app/")({ component: lazyRouteComponent($$splitComponentImporter$26, "component") });
var $$splitComponentImporter$25 = () => import("./alphabet-DrnPtYiL.mjs");
var Route$25 = createFileRoute("/_app/alphabet")({ component: lazyRouteComponent($$splitComponentImporter$25, "component") });
var $$splitComponentImporter$24 = () => import("./dictionary-CWn3m9kQ.mjs");
var Route$24 = createFileRoute("/_app/dictionary")({
	validateSearch: (s) => ({ q: typeof s.q === "string" ? s.q : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./favorites-Czib5QJO.mjs");
var Route$23 = createFileRoute("/_app/favorites")({ component: lazyRouteComponent($$splitComponentImporter$23, "component") });
var $$splitComponentImporter$22 = () => import("./flashcards-BsUW_uRG.mjs");
var Route$22 = createFileRoute("/_app/flashcards")({ component: lazyRouteComponent($$splitComponentImporter$22, "component") });
var $$splitComponentImporter$21 = () => import("./grammar-D3e4U9b7.mjs");
var Route$21 = createFileRoute("/_app/grammar")({ component: lazyRouteComponent($$splitComponentImporter$21, "component") });
var $$splitComponentImporter$20 = () => import("./hiragana-B62NDVXS.mjs");
var Route$20 = createFileRoute("/_app/hiragana")({ component: lazyRouteComponent($$splitComponentImporter$20, "component") });
var $$splitComponentImporter$19 = () => import("./kanji-BXqyQt_N.mjs");
var Route$19 = createFileRoute("/_app/kanji")({ component: lazyRouteComponent($$splitComponentImporter$19, "component") });
var $$splitComponentImporter$18 = () => import("./katakana-B7fTZYrm.mjs");
var Route$18 = createFileRoute("/_app/katakana")({ component: lazyRouteComponent($$splitComponentImporter$18, "component") });
var $$splitComponentImporter$17 = () => import("./listen-DgLOFeZy.mjs");
var Route$17 = createFileRoute("/_app/listen")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("./my-words-DLkd7_kT.mjs");
var Route$16 = createFileRoute("/_app/my-words")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./path-BZH2i9ac.mjs");
var Route$15 = createFileRoute("/_app/path")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./quiz-C4f1PLYs.mjs");
var Route$14 = createFileRoute("/_app/quiz")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./read-6hWSwiAF.mjs");
var Route$13 = createFileRoute("/_app/read")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./review-DPGT9B_L.mjs");
var Route$12 = createFileRoute("/_app/review")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./romaji-Bv5kJeCj.mjs");
var Route$11 = createFileRoute("/_app/romaji")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./settings-B4_dO7JX.mjs");
var Route$10 = createFileRoute("/_app/settings")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./stats-Cr4lGZe8.mjs");
var Route$9 = createFileRoute("/_app/stats")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./vocabulary-Cm2mT1jx.mjs");
var Route$8 = createFileRoute("/_app/vocabulary")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./dictionary._id-Daykm_GX.mjs");
var Route$7 = createFileRoute("/_app/dictionary/$id")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./grammar._id-BBA-GspD.mjs");
var Route$6 = createFileRoute("/_app/grammar/$id")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./hiragana._id-eoS0uak-.mjs");
var Route$5 = createFileRoute("/_app/hiragana/$id")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./kanji._id-CLpWTEe_.mjs");
var Route$4 = createFileRoute("/_app/kanji/$id")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./katakana._id-BFPF1TPc.mjs");
var Route$3 = createFileRoute("/_app/katakana/$id")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./path._id-BVGtUwiH.mjs");
var Route$2 = createFileRoute("/_app/path/$id")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./tools.import-dictionary-yZkNNSr2.mjs");
var Route$1 = createFileRoute("/_app/tools/import-dictionary")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./vocabulary._id-CtWa6FOp.mjs");
var Route = createFileRoute("/_app/vocabulary/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var AppRoute = Route$27.update({
	id: "/_app",
	getParentRoute: () => Route$28
});
var AppIndexRoute = Route$26.update({
	id: "/",
	path: "/",
	getParentRoute: () => AppRoute
});
var AppAlphabetRoute = Route$25.update({
	id: "/alphabet",
	path: "/alphabet",
	getParentRoute: () => AppRoute
});
var AppDictionaryRoute = Route$24.update({
	id: "/dictionary",
	path: "/dictionary",
	getParentRoute: () => AppRoute
});
var AppFavoritesRoute = Route$23.update({
	id: "/favorites",
	path: "/favorites",
	getParentRoute: () => AppRoute
});
var AppFlashcardsRoute = Route$22.update({
	id: "/flashcards",
	path: "/flashcards",
	getParentRoute: () => AppRoute
});
var AppGrammarRoute = Route$21.update({
	id: "/grammar",
	path: "/grammar",
	getParentRoute: () => AppRoute
});
var AppHiraganaRoute = Route$20.update({
	id: "/hiragana",
	path: "/hiragana",
	getParentRoute: () => AppRoute
});
var AppKanjiRoute = Route$19.update({
	id: "/kanji",
	path: "/kanji",
	getParentRoute: () => AppRoute
});
var AppKatakanaRoute = Route$18.update({
	id: "/katakana",
	path: "/katakana",
	getParentRoute: () => AppRoute
});
var AppListenRoute = Route$17.update({
	id: "/listen",
	path: "/listen",
	getParentRoute: () => AppRoute
});
var AppMyWordsRoute = Route$16.update({
	id: "/my-words",
	path: "/my-words",
	getParentRoute: () => AppRoute
});
var AppPathRoute = Route$15.update({
	id: "/path",
	path: "/path",
	getParentRoute: () => AppRoute
});
var AppQuizRoute = Route$14.update({
	id: "/quiz",
	path: "/quiz",
	getParentRoute: () => AppRoute
});
var AppReadRoute = Route$13.update({
	id: "/read",
	path: "/read",
	getParentRoute: () => AppRoute
});
var AppReviewRoute = Route$12.update({
	id: "/review",
	path: "/review",
	getParentRoute: () => AppRoute
});
var AppRomajiRoute = Route$11.update({
	id: "/romaji",
	path: "/romaji",
	getParentRoute: () => AppRoute
});
var AppSettingsRoute = Route$10.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AppRoute
});
var AppStatsRoute = Route$9.update({
	id: "/stats",
	path: "/stats",
	getParentRoute: () => AppRoute
});
var AppVocabularyRoute = Route$8.update({
	id: "/vocabulary",
	path: "/vocabulary",
	getParentRoute: () => AppRoute
});
var AppDictionaryIdRoute = Route$7.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppDictionaryRoute
});
var AppGrammarIdRoute = Route$6.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppGrammarRoute
});
var AppHiraganaIdRoute = Route$5.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppHiraganaRoute
});
var AppKanjiIdRoute = Route$4.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppKanjiRoute
});
var AppKatakanaIdRoute = Route$3.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppKatakanaRoute
});
var AppPathIdRoute = Route$2.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppPathRoute
});
var AppToolsImportDictionaryRoute = Route$1.update({
	id: "/tools/import-dictionary",
	path: "/tools/import-dictionary",
	getParentRoute: () => AppRoute
});
var AppVocabularyIdRoute = Route.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppVocabularyRoute
});
var AppDictionaryRouteChildren = { AppDictionaryIdRoute };
var AppDictionaryRouteWithChildren = AppDictionaryRoute._addFileChildren(AppDictionaryRouteChildren);
var AppGrammarRouteChildren = { AppGrammarIdRoute };
var AppGrammarRouteWithChildren = AppGrammarRoute._addFileChildren(AppGrammarRouteChildren);
var AppHiraganaRouteChildren = { AppHiraganaIdRoute };
var AppHiraganaRouteWithChildren = AppHiraganaRoute._addFileChildren(AppHiraganaRouteChildren);
var AppKanjiRouteChildren = { AppKanjiIdRoute };
var AppKanjiRouteWithChildren = AppKanjiRoute._addFileChildren(AppKanjiRouteChildren);
var AppKatakanaRouteChildren = { AppKatakanaIdRoute };
var AppKatakanaRouteWithChildren = AppKatakanaRoute._addFileChildren(AppKatakanaRouteChildren);
var AppPathRouteChildren = { AppPathIdRoute };
var AppPathRouteWithChildren = AppPathRoute._addFileChildren(AppPathRouteChildren);
var AppVocabularyRouteChildren = { AppVocabularyIdRoute };
var AppRouteChildren = {
	AppAlphabetRoute,
	AppDictionaryRoute: AppDictionaryRouteWithChildren,
	AppFavoritesRoute,
	AppFlashcardsRoute,
	AppGrammarRoute: AppGrammarRouteWithChildren,
	AppHiraganaRoute: AppHiraganaRouteWithChildren,
	AppKanjiRoute: AppKanjiRouteWithChildren,
	AppKatakanaRoute: AppKatakanaRouteWithChildren,
	AppListenRoute,
	AppMyWordsRoute,
	AppPathRoute: AppPathRouteWithChildren,
	AppQuizRoute,
	AppReadRoute,
	AppReviewRoute,
	AppRomajiRoute,
	AppSettingsRoute,
	AppStatsRoute,
	AppVocabularyRoute: AppVocabularyRoute._addFileChildren(AppVocabularyRouteChildren),
	AppIndexRoute,
	AppToolsImportDictionaryRoute
};
var rootRouteChildren = { AppRoute: AppRoute._addFileChildren(AppRouteChildren) };
var routeTree = Route$28._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$4 as a, Route$7 as c, Route$3 as i, Route$24 as l, Route as n, Route$5 as o, Route$2 as r, Route$6 as s, router_exports as t, __exportAll as u };
