import { a as allImportedDictionary } from "./storage-BOiNWlU7.mjs";
import { r as kanaById } from "./kana-CV-aAiLY.mjs";
import { n as KANJI_N5, t as KANJI_N4 } from "./kanji-n4-Bq9tkueZ.mjs";
import { n as VOCAB_N5, t as VOCAB_N4 } from "./vocabulary-n4-Bzb_ewCa.mjs";
import { n as GRAMMAR_N5, t as GRAMMAR_N4 } from "./grammar-n4-Dv0a1spF.mjs";
import { n as hasKanji } from "./romaji-DAIxYx-y.mjs";
import { n as searchLocal, t as buildDictionary } from "./local-CAR8tw6H.mjs";
import { t as DICTIONARY_EXTRA } from "./dictionary-extra-Ca9ZP6BQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-Dl3G3Fgy.js
var builtin = null;
function builtinDictionary() {
	if (!builtin) builtin = buildDictionary([...VOCAB_N5, ...VOCAB_N4], [...KANJI_N5, ...KANJI_N4], DICTIONARY_EXTRA);
	return builtin;
}
function mergeDictionary(extra = []) {
	const map = /* @__PURE__ */ new Map();
	for (const e of builtinDictionary()) map.set(e.id, e);
	for (const e of extra) map.set(e.id, e);
	return [...map.values()];
}
async function fullDictionary() {
	try {
		return mergeDictionary(await allImportedDictionary());
	} catch {
		return builtinDictionary();
	}
}
function findBuiltin(id) {
	return builtinDictionary().find((e) => e.id === id);
}
function searchDictionary(dict, query) {
	return searchLocal(dict, query);
}
function allKanji() {
	return [...KANJI_N5, ...KANJI_N4];
}
function kanjiByChar(ch) {
	return allKanji().find((k) => k.character === ch);
}
function kanjiInWord(word, entry) {
	return (entry?.kanjiChars?.length ? entry.kanjiChars : [...word].filter((c) => hasKanji(c))).map((c) => ({
		char: c,
		entry: kanjiByChar(c)
	}));
}
function resolveStudyItem(id) {
	const kana = kanaById(id);
	if (kana) return {
		id,
		title: kana.char,
		sub: kana.romaji,
		to: `/${kana.kind}/${kana.id}`,
		type: kana.kind === "hiragana" ? "Hiragana" : "Katakana",
		speak: kana.char
	};
	const vocab = [...VOCAB_N5, ...VOCAB_N4].find((v) => v.id === id);
	if (vocab) return {
		id,
		title: vocab.word,
		sub: vocab.meaning_vi,
		to: `/vocabulary/${vocab.id}`,
		type: "Từ vựng",
		speak: vocab.word
	};
	const kj = allKanji().find((k) => k.id === id);
	if (kj) return {
		id,
		title: kj.character,
		sub: kj.meaning_vi,
		to: `/kanji/${kj.id}`,
		type: "Kanji",
		speak: kj.character
	};
	const g = [...GRAMMAR_N5, ...GRAMMAR_N4].find((x) => x.id === id);
	if (g) return {
		id,
		title: g.name,
		sub: g.meaning_vi,
		to: `/grammar/${g.id}`,
		type: "Ngữ pháp"
	};
	const d = findBuiltin(id);
	if (d) return {
		id,
		title: d.kanji,
		sub: d.meanings[0] ?? d.kana,
		to: `/dictionary/${d.id}`,
		type: "Từ điển",
		speak: d.kanji
	};
	return {
		id,
		title: id,
		sub: "Mục tùy chọn",
		to: `/dictionary/${id}`,
		type: "Khác"
	};
}
var POS_FILTERS = [
	"danh từ",
	"động từ",
	"tính từ -i",
	"tính từ -na",
	"trạng từ",
	"trợ từ",
	"biểu hiện"
];
//#endregion
export { kanjiInWord as a, searchDictionary as c, fullDictionary as i, builtinDictionary as n, mergeDictionary as o, findBuiltin as r, resolveStudyItem as s, POS_FILTERS as t };
