import { i as __toESM } from "../_runtime.mjs";
import { E as require_jsx_runtime, T as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as PageHeader } from "./page-header-BwwPPGfl.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as GRAMMAR_N5, t as GRAMMAR_N4 } from "./grammar-n4-Dv0a1spF.mjs";
import { t as Badge } from "./badge-COPtWlVw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/grammar-D3e4U9b7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [lv, setLv] = (0, import_react.useState)("all");
	const all = [...GRAMMAR_N5, ...GRAMMAR_N4].filter((g) => lv === "all" || g.level === lv);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "文法",
			title: "Ngữ pháp",
			description: "Cấu trúc, cách dùng, ví dụ gốc và lỗi thường gặp — giải thích bằng tiếng Việt."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex gap-2",
			children: [
				"all",
				"N5",
				"N4"
			].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setLv(x),
				className: `h-10 rounded-[10px] border px-3 text-sm ${lv === x ? "border-primary bg-primary text-primary-fg" : "border-border"}`,
				children: x === "all" ? "Tất cả" : x
			}, x))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: all.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/grammar/$id",
				params: { id: g.id },
				className: "block rounded-xl border border-border bg-surface px-4 py-3 hover:border-accent",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-jp text-lg",
						children: g.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "muted",
						children: g.level
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						g.structure,
						" — ",
						g.meaning_vi
					]
				})]
			}) }, g.id))
		})
	] });
}
//#endregion
export { Page as component };
