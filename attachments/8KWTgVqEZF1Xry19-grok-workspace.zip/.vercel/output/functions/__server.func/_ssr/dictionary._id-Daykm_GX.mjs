import { i as __toESM } from "../_runtime.mjs";
import { E as require_jsx_runtime, T as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-c9IIymTs.mjs";
import { n as useSettings } from "./settings-CfMxctWi.mjs";
import { i as useProgress } from "./progress-DkeQVu5t.mjs";
import { n as CardContent, t as Card } from "./card-7M-NYlJ1.mjs";
import { v as Link, z as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as BookmarkPlus, a as Star } from "../_libs/lucide-react.mjs";
import { a as kanjiInWord, i as fullDictionary, n as builtinDictionary } from "./catalog-Dl3G3Fgy.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as Route$7 } from "./router-YoCxU7dM.mjs";
import { t as Badge } from "./badge-COPtWlVw.mjs";
import { t as SpeakButton } from "./speak-button-DDCQe5zF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dictionary._id-Daykm_GX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DictActions({ entry, itemType = "vocab" }) {
	const fav = useProgress((s) => s.favorites.has(entry.id));
	const mine = useProgress((s) => s.myWords.has(entry.id));
	const toggleFav = useProgress((s) => s.toggleFav);
	const addStudy = useProgress((s) => s.addToStudy);
	const remember = useProgress((s) => s.remember);
	const forgot = useProgress((s) => s.forgot);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: fav ? "default" : "secondary",
				onClick: async () => {
					const on = await toggleFav(entry.id, itemType);
					toast(on ? "Đã thêm yêu thích" : "Đã bỏ yêu thích");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {}),
					" ",
					fav ? "Đã thích" : "Yêu thích"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: mine ? "default" : "secondary",
				onClick: async () => {
					await addStudy(entry.id, itemType);
					toast("Đã thêm vào danh sách học");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkPlus, {}),
					" ",
					mine ? "Trong từ của tôi" : "Thêm vào học"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => void forgot(entry.id, itemType),
				children: "Cần ôn"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "success",
				onClick: () => void remember(entry.id, itemType),
				children: "Đã nhớ"
			})
		]
	});
}
function DictEntryView({ entry }) {
	const showRomaji = useSettings((s) => s.showRomaji);
	const kanji = kanjiInWord(entry.kanji, entry);
	const posLabel = entry.part_of_speech.join(" · ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "py-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-center gap-1.5",
						children: [entry.jlpt.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: ["JLPT ", l] }, l)), entry.common ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "success",
							children: "Phổ biến"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-kana mt-4 text-6xl",
						children: entry.kanji
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-jp text-xl text-muted",
						children: entry.kana
					}),
					showRomaji ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-accent",
						children: entry.romaji
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-1",
						children: entry.meanings.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-lg",
							children: m
						}, m))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm capitalize text-subtle",
						children: posLabel
					}),
					entry.pitch_accent != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: ["Pitch accent: ", entry.pitch_accent]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeakButton, {
						className: "mx-auto mt-4",
						text: entry.kanji
					})
				]
			}) }),
			entry.examples.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm text-muted",
					children: "Ví dụ"
				}), entry.examples.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border pt-3 first:border-0 first:pt-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-jp text-lg",
								children: ex.jp
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeakButton, {
								text: ex.jp,
								label: "Nghe câu"
							})]
						}),
						ex.kana ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: ex.kana
						}) : null,
						showRomaji && ex.romaji ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-accent",
							children: ex.romaji
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: ex.vi
						})
					]
				}, ex.jp))]
			}) }) : null,
			kanji.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm text-muted",
				children: "Kanji trong từ"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: kanji.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3",
					children: [k.entry ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/kanji/$id",
						params: { id: k.entry.id },
						className: "font-jp text-2xl hover:underline",
						children: k.char
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-jp text-2xl",
						children: k.char
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: k.entry ? k.entry.meaning_vi : "Chưa có trong bộ kanji N5/N4"
					})]
				}, k.char))
			})] }) }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DictActions, { entry })
		]
	});
}
function Page() {
	const { id } = Route$7.useParams();
	const [entry, setEntry] = (0, import_react.useState)(() => builtinDictionary().find((e) => e.id === id) ?? null);
	const [ready, setReady] = (0, import_react.useState)(Boolean(entry));
	(0, import_react.useEffect)(() => {
		let alive = true;
		fullDictionary().then((dict) => {
			if (!alive) return;
			setEntry(dict.find((e) => e.id === id) ?? null);
			setReady(true);
		});
		return () => {
			alive = false;
		};
	}, [id]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Đang mở mục từ…"
	});
	if (!entry) throw notFound();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "ghost",
			size: "sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/dictionary",
				children: "← Từ điển"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DictEntryView, { entry })]
	});
}
//#endregion
export { Page as component };
