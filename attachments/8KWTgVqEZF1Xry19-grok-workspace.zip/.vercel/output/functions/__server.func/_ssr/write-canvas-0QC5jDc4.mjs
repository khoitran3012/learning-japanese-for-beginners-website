import { i as __toESM } from "../_runtime.mjs";
import { E as require_jsx_runtime, T as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-c9IIymTs.mjs";
import { b as Eraser, c as RotateCcw } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/write-canvas-0QC5jDc4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WriteCanvas({ character, strokeCount }) {
	const ref = (0, import_react.useRef)(null);
	const drawing = (0, import_react.useRef)(false);
	const strokes = (0, import_react.useRef)([]);
	const [count, setCount] = (0, import_react.useState)(0);
	function pos(e, canvas) {
		const r = canvas.getBoundingClientRect();
		return {
			x: (e.clientX - r.left) / r.width * canvas.width,
			y: (e.clientY - r.top) / r.height * canvas.height
		};
	}
	function redraw() {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.fillStyle = getComputedStyle(canvas).getPropertyValue("--guide") || "transparent";
		ctx.font = "280px 'Noto Serif JP', serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.globalAlpha = .08;
		ctx.fillStyle = "#1c1917";
		ctx.fillText(character, canvas.width / 2, canvas.height / 2 + 20);
		ctx.globalAlpha = 1;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.strokeStyle = "#2f4158";
		ctx.lineWidth = 14;
		for (const s of strokes.current) {
			if (!s.length) continue;
			ctx.beginPath();
			ctx.moveTo(s[0].x, s[0].y);
			for (const p of s.slice(1)) ctx.lineTo(p.x, p.y);
			ctx.stroke();
		}
	}
	(0, import_react.useEffect)(() => {
		strokes.current = [];
		setCount(0);
		redraw();
	}, [character]);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const onDown = (e) => {
			drawing.current = true;
			canvas.setPointerCapture(e.pointerId);
			strokes.current.push([pos(e, canvas)]);
		};
		const onMove = (e) => {
			if (!drawing.current) return;
			strokes.current[strokes.current.length - 1]?.push(pos(e, canvas));
			redraw();
		};
		const onUp = () => {
			if (drawing.current) setCount(strokes.current.length);
			drawing.current = false;
		};
		canvas.addEventListener("pointerdown", onDown);
		canvas.addEventListener("pointermove", onMove);
		canvas.addEventListener("pointerup", onUp);
		canvas.addEventListener("pointercancel", onUp);
		redraw();
		return () => {
			canvas.removeEventListener("pointerdown", onDown);
			canvas.removeEventListener("pointermove", onMove);
			canvas.removeEventListener("pointerup", onUp);
			canvas.removeEventListener("pointercancel", onUp);
		};
	}, [character]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Viết thử ", strokeCount ? `· ${strokeCount} nét mẫu` : ""] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums",
					children: [count, " nét đã viết"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref,
				width: 420,
				height: 420,
				className: "w-full touch-none rounded-lg border border-border bg-bg-elevated",
				style: {
					aspectRatio: "1 / 1",
					touchAction: "none"
				},
				"aria-label": `Vùng viết chữ ${character}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "secondary",
					size: "sm",
					onClick: () => {
						strokes.current = [];
						setCount(0);
						redraw();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {}), " Xóa"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					onClick: () => {
						strokes.current.pop();
						setCount(strokes.current.length);
						redraw();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), " Hoàn tác"]
				})]
			})
		]
	});
}
//#endregion
export { WriteCanvas as t };
