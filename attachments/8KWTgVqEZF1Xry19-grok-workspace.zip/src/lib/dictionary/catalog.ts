import { VOCAB_N5 } from "@/data/vocabulary-n5";
import { VOCAB_N4 } from "@/data/vocabulary-n4";
import { KANJI_N5 } from "@/data/kanji-n5";
import { KANJI_N4 } from "@/data/kanji-n4";
import { GRAMMAR_N5 } from "@/data/grammar-n5";
import { GRAMMAR_N4 } from "@/data/grammar-n4";
import { DICTIONARY_EXTRA } from "@/data/dictionary-extra";
import { kanaById } from "@/data/kana";
import { buildDictionary, searchLocal } from "./local";
import { hasKanji } from "@/lib/akari/romaji";
import type { DictionaryEntry, KanjiEntry } from "@/lib/akari/types";
import type { SearchQuery } from "@/lib/api/data-provider";
import { allImportedDictionary } from "@/lib/akari/storage";

let builtin: DictionaryEntry[] | null = null;
let importedCache: DictionaryEntry[] = [];

export function builtinDictionary(): DictionaryEntry[] {
  if (!builtin) {
    builtin = buildDictionary([...VOCAB_N5, ...VOCAB_N4], [...KANJI_N5, ...KANJI_N4], DICTIONARY_EXTRA);
  }
  return builtin;
}

export function rememberImported(entries: DictionaryEntry[]) {
  const map = new Map(importedCache.map((e) => [e.id, e]));
  for (const e of entries) map.set(e.id, e);
  importedCache = [...map.values()];
}

export function mergeDictionary(extra: DictionaryEntry[] = []): DictionaryEntry[] {
  return buildDictionary([...VOCAB_N5, ...VOCAB_N4], [...KANJI_N5, ...KANJI_N4], [...DICTIONARY_EXTRA, ...extra]);
}

export async function fullDictionary(): Promise<DictionaryEntry[]> {
  try {
    const imported = await allImportedDictionary();
    importedCache = imported;
    return mergeDictionary(imported);
  } catch {
    return builtinDictionary();
  }
}

export function findBuiltin(id: string) {
  return builtinDictionary().find((e) => e.id === id);
}

export function findEntry(id: string) {
  return findBuiltin(id) ?? importedCache.find((e) => e.id === id);
}

export function searchDictionary(dict: DictionaryEntry[], query: SearchQuery) {
  return searchLocal(dict, query);
}

export function allKanji(): KanjiEntry[] {
  return [...KANJI_N5, ...KANJI_N4];
}

export function kanjiByChar(ch: string) {
  return allKanji().find((k) => k.character === ch);
}

export function kanjiInWord(word: string, entry?: DictionaryEntry) {
  const chars = entry?.kanjiChars?.length
    ? entry.kanjiChars
    : [...word].filter((c) => hasKanji(c));
  return chars.map((c) => ({ char: c, entry: kanjiByChar(c) }));
}

export interface ResolvedItem {
  id: string;
  title: string;
  sub: string;
  to: string;
  type: string;
  speak?: string;
}

export function resolveStudyItem(id: string): ResolvedItem | null {
  const kana = kanaById(id);
  if (kana) {
    return {
      id,
      title: kana.char,
      sub: kana.romaji,
      to: `/${kana.kind}/${kana.id}`,
      type: kana.kind === "hiragana" ? "Hiragana" : "Katakana",
      speak: kana.char,
    };
  }
  const vocab = [...VOCAB_N5, ...VOCAB_N4].find((v) => v.id === id);
  if (vocab) {
    return {
      id,
      title: vocab.word,
      sub: vocab.meaning_vi,
      to: `/vocabulary/${vocab.id}`,
      type: "Từ vựng",
      speak: vocab.word,
    };
  }
  const kj = allKanji().find((k) => k.id === id);
  if (kj) {
    return {
      id,
      title: kj.character,
      sub: kj.meaning_vi,
      to: `/kanji/${kj.id}`,
      type: "Kanji",
      speak: kj.character,
    };
  }
  const g = [...GRAMMAR_N5, ...GRAMMAR_N4].find((x) => x.id === id);
  if (g) {
    return {
      id,
      title: g.name,
      sub: g.meaning_vi,
      to: `/grammar/${g.id}`,
      type: "Ngữ pháp",
    };
  }
  const d = findEntry(id);
  if (d) {
    return {
      id,
      title: d.kanji,
      sub: d.meanings[0] ?? d.kana,
      to: `/dictionary/${d.id}`,
      type: "Từ điển",
      speak: d.kanji,
    };
  }
  return {
    id,
    title: id,
    sub: "Mục tùy chọn",
    to: `/dictionary/${id}`,
    type: "Khác",
  };
}

export const POS_FILTERS = [
  "danh từ",
  "động từ",
  "tính từ -i",
  "tính từ -na",
  "trạng từ",
  "trợ từ",
  "biểu hiện",
] as const;
